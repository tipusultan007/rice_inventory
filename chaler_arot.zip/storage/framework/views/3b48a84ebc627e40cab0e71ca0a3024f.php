<?php if($payment->customer_id != ""): ?>
    <div class="row mb-3">
        <div class="col-md-3">
            <label for="customer_id">ক্রেতা</label>
        </div>
        <div class="col-md-9">
            <input type="hidden" name="customer_id" value="<?php echo e($payment->customer_id); ?>">
            <input type="text" class="form-control" value="<?php echo e($payment->customer->name); ?>">
        </div>
    </div>
<?php else: ?>
    <div class="row mb-3">
        <div class="col-md-3">
            <label for="supplier_id">সরবরাহকারী</label>
        </div>
        <div class="col-md-9">
            <input type="hidden" name="supplier_id" value="<?php echo e($payment->supplier_id); ?>">
            <input type="text" class="form-control" value="<?php echo e($payment->supplier->name); ?>">
        </div>
    </div>
<?php endif; ?>
<?php if($payment->customer_id != ""): ?>
    <div class="row mb-3">
        <div class="col-md-3">
            <label for="type">ধরন</label>
        </div>
        <div class="col-md-9">
            <select name="type" class="select2 form-control" id="type">
                <option value="credit" <?php echo e($payment->type === 'credit'?'selected':''); ?>>পরিশোধ</option>
                <option value="debit" <?php echo e($payment->type === 'debit'?'selected':''); ?>>বকেয়া</option>
            </select>
        </div>
    </div>
<?php else: ?>
    <div class="row mb-3">
        <div class="col-md-3">
            <label for="type">ধরন</label>
        </div>
        <div class="col-md-9">
            <select name="type" class="select2 form-control" id="type">
                <option value="credit" <?php echo e($payment->type === 'credit'?'selected':''); ?>>বকেয়া</option>
                <option value="debit" <?php echo e($payment->type === 'debit'?'selected':''); ?>>পরিশোধ</option>
            </select>
        </div>
    </div>
<?php endif; ?>
<div class="row mb-3">
    <div class="col-md-3">
        <label for="amount">টাকা</label>
    </div>
    <div class="col-md-9">
        <input type="number" class="form-control" name="amount" value="<?php echo e($payment->amount); ?>" required>
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-3">
        <label for="date">তারিখ</label>
    </div>
    <div class="col-md-9">
        <input type="date" class="form-control" name="date" value="<?php echo e($payment->date); ?>"
               required>
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-3">
        <label for="payment_method_id">পেমেন্ট মাধ্যম</label>
    </div>
    <div class="col-md-9">
        <select name="payment_method_id"
                class="form-control select2">
            <option value=""></option>
            <?php $__empty_1 = true; $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($method->id); ?>" <?php echo e($payment->payment_method_id == $method->id?'selected':''); ?>><?php echo e($method->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>
</div>
<input type="hidden" name="user_id" value="<?php echo e(auth()->id()); ?>">
<div class="row mb-3">
    <div class="col-md-3">

    </div>
    <div class="col-md-9">
        <button class="btn btn-primary" type="submit">আপডেট</button>
    </div>
</div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/payment/form.blade.php ENDPATH**/ ?>