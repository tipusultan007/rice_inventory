<input
    name="<?php echo e($name); ?>"
    type="text"
    id="<?php echo e($id); ?>"
    placeholder="<?php echo e($placeholder); ?>"
    <?php if($value): ?> value="<?php echo e($value); ?>" <?php endif; ?>
    <?php echo e($attributes->merge(['class' => config('tablar-kit.default-class'). ' flatpickr'])); ?>

/>

<?php if (! $__env->hasRenderedOnce('6d9c6a5c-4f6b-44c2-92a9-646aedde8328')): $__env->markAsRenderedOnce('6d9c6a5c-4f6b-44c2-92a9-646aedde8328'); ?>
    <?php $__env->startPush('js'); ?>
        <script type="module">
            document.addEventListener('DOMContentLoaded', function () {
                window.flatpickr(".flatpickr", {
                    "altFormat": "d-m-Y",
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('css'); ?>
        <style>

        </style>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/vendor/tablar-kit/components/forms/inputs/flat-picker.blade.php ENDPATH**/ ?>