
<div class="form-group mb-3">
    <label class="form-label">নাম</label>
    <div>
        <?php echo e(Form::text('name', $asset->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">বিবরণ</label>
    <div>
        <?php echo e(Form::text('description', $asset->description, ['class' => 'form-control' .
        ($errors->has('description') ? ' is-invalid' : ''), 'placeholder' => 'Description'])); ?>

        <?php echo $errors->first('description', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">মূল্য</label>
    <div>
        <?php echo e(Form::text('value', $asset->value, ['class' => 'form-control' .
        ($errors->has('value') ? ' is-invalid' : ''), 'placeholder' => 'Value'])); ?>

        <?php echo $errors->first('value', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">তারিখ</label>
    <div>
        <?php echo e(Form::text('date', $asset->date, ['class' => 'form-control flatpicker' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label"> অ্যাকাউন্ট</label>
    <select name="account_id" class="form-control select2" id="account_id" data-placeholder="সিলেক্ট অ্যাকাউন্ট">
        <option value=""></option>
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($account->id); ?>" <?php echo e(isset($transaction)? $account->id == $transaction->account_id?'selected':'':''); ?>><?php echo e($account->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" id="submitButton" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/asset/form.blade.php ENDPATH**/ ?>