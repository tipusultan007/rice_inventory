<?php $__env->startSection('title', 'View Bank Loan'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <div class="page-pretitle">
                        View
                    </div>
                    <h2 class="page-title">
                        <?php echo e(__('Bank Loan ')); ?>

                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <a href="<?php echo e(route('bank_loans.index')); ?>" class="btn btn-primary d-none d-sm-inline-block">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19"/>
                                <line x1="5" y1="12" x2="19" y2="12"/>
                            </svg>
                            Bank Loan List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <?php if(config('tablar','display_alert')): ?>
                        <?php echo $__env->make('tablar::common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
                <div class="col-3">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">লোন বিবরণ</h3>
                        </div>
                        <div class="card-body">

                            <div class="form-group">
                                <h5 class="mb-1">ঋণ'র নাম</h5>
                                <p><?php echo e($bankLoan->name); ?></p>
                            </div>
                            <div class="form-group">
                                <h5 class="mb-1">ঋণ'র পরিমাণ</h5>
                                <p> <?php echo e($bankLoan->loan_amount); ?></p>
                            </div>
                            <div class="form-group">
                                <h5 class="mb-1">লভ্যাংশ</h5>
                                <p><?php echo e($bankLoan->interest); ?></p>
                            </div>
                            <div class="form-group">
                                <h5 class="mb-1">সর্বমোট</h5>
                                <p><?php echo e($bankLoan->total_loan); ?></p>
                            </div>
                            <div class="form-group">
                                <h5 class="mb-1">তারিখ</h5>
                                <p><?php echo e(date('d/m/Y',strtotime($bankLoan->date))); ?></p>
                            </div>
                            <?php if($bankLoan->description): ?>
                                <div class="form-group">
                                    <h5 class="mb-1">বিবরণ</h5>
                                    <p><?php echo e($bankLoan->description); ?></p>
                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <h5 class="mb-1">ছাড়</h5>
                                <p><?php echo e($bankLoan->grace); ?></p>
                            </div>
                            <div class="form-group">
                                <h5 class="mb-1">ব্যালেন্স</h5>
                                <p><?php echo e($bankLoan->balance); ?></p>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-9">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead class="thead-light">
                                <tr>
                                    <th class="fw-bolder fs-4">তারিখ</th>
                                    <th class="fw-bolder fs-4 text-end">ঋণ পরিশোধ</th>
                                    <th class="fw-bolder fs-4 text-end">লভ্যাংশ</th>
                                    <th class="fw-bolder fs-4 text-end">ছাড়</th>
                                    <th class="fw-bolder fs-4 text-end">ব্যালেন্স</th>
                                    <th class="fw-bolder fs-4 text-end">অ্যাকশন</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(date('d/m/Y',strtotime($transaction->date))); ?></td>
                                        <td><?php echo e($transaction->amount); ?></td>
                                        <td><?php echo e($transaction->interest??'-'); ?></td>
                                        <td><?php echo e($transaction->grace??'-'); ?></td>
                                        <td><?php echo e($transaction->balance??'-'); ?></td>
                                       <td>
                                           <form
                                               action="<?php echo e(route('bank_loan_repayments.destroy',$transaction->id)); ?>"
                                               method="POST">
                                               <?php echo csrf_field(); ?>
                                               <?php echo method_field('DELETE'); ?>
                                               <button type="submit"
                                                       onclick="if(!confirm('Do you Want to Proceed?')){return false;}"
                                                       class="btn btn-sm btn-danger"><i
                                                       class="fa fa-fw fa-trash"></i>
                                                   Delete
                                               </button>
                                           </form>
                                       </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('tablar::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chaler_arot\resources\views/bank-loan/show.blade.php ENDPATH**/ ?>