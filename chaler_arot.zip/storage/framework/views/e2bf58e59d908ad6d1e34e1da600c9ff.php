
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('name')); ?></label>
    <div>
        <?php echo e(Form::text('name', $paymentMethod->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">paymentMethod <b>name</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('details')); ?></label>
    <div>
        <?php echo e(Form::text('details', $paymentMethod->details, ['class' => 'form-control' .
        ($errors->has('details') ? ' is-invalid' : ''), 'placeholder' => 'Details'])); ?>

        <?php echo $errors->first('details', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">paymentMethod <b>details</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/payment-method/form.blade.php ENDPATH**/ ?>