
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('amount','তহরি')); ?></label>
    <div>
        <?php echo e(Form::text('amount', $tohori->amount, ['class' => 'form-control' .
        ($errors->has('amount') ? ' is-invalid' : ''), 'placeholder' => 'Amount'])); ?>

        <?php echo $errors->first('amount', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('date','তারিখ')); ?></label>
    <div>
        <?php echo e(Form::text('date', $tohori->date, ['class' => 'form-control flatpicker' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">সাবমিট</button>
            </div>
        </div>
    </div>
<script type="module">
    document.addEventListener('DOMContentLoaded', function () {
        window.flatpickr(".flatpicker", {
            altInput: true,
            allowInput: true,
            altFormat: "d-m-Y",
            dateFormat: "Y-m-d",
            defaultDate: "<?php echo e(date('Y-m-d')); ?>"
        });
    });
</script>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/tohori/form.blade.php ENDPATH**/ ?>