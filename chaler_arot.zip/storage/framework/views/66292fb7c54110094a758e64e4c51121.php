<div class="card-body">
    <?php if(isset($slot)): ?>
        <?php echo e($slot); ?>

    <?php endif; ?>
</div>
<?php /**PATH C:\wamp64\www\chaler_arot\vendor\takielias\tablar-kit\src/../resources/views/components/cards/body.blade.php ENDPATH**/ ?>