<?php
    use App\Models\Account;
    $accounts = Account::pluck('name','id');
?>

<div class="form-group mb-3">
    <label class="form-label" for="from_account_id">From Account</label>
    <select name="from_account_id" id="from_account_id" class="form-control select2">
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e($balanceTransfer->from_account_id == $key ?'selected':''); ?>><?php echo e($account); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group mb-3">
    <label class="form-label" for="to_account_id">To Account</label>
    <select name="to_account_id" id="to_account_id" class="form-control select2">
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e($balanceTransfer->to_account_id == $key ?'selected':''); ?>><?php echo e($account); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('amount')); ?></label>
    <div>
        <?php echo e(Form::text('amount', $balanceTransfer->amount, ['class' => 'form-control' .
        ($errors->has('amount') ? ' is-invalid' : ''), 'placeholder' => 'Amount'])); ?>

        <?php echo $errors->first('amount', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">balanceTransfer <b>amount</b> instruction.</small>
    </div>
</div>

<div class="form-footer">
    <div class="text-end">
        <div class="d-flex">
            <a href="#" class="btn btn-danger">Cancel</a>
            <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
        </div>
    </div>
</div>

<script type="module">
    $(".select2").select2({
        theme: "bootstrap-5",
        width: "100%",
        placeholder: "একাউন্ট সিলেক্ট করুন"
    });
</script>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/balance-transfer/form.blade.php ENDPATH**/ ?>