<div class="card-header">
    <?php if(isset($slot)): ?>
        <h3 class="card-title"><?php echo e($slot); ?></h3>
    <?php endif; ?>
</div>
<?php /**PATH C:\wamp64\www\chaler_arot\vendor\takielias\tablar-kit\src/../resources/views/components/cards/header.blade.php ENDPATH**/ ?>