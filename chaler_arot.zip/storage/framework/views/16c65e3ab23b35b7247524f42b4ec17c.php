<?php $__env->startSection('title'); ?>
    Asset Sell
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <div class="page-pretitle">
                        List
                    </div>
                    <h2 class="page-title">
                        <?php echo e(__('Asset Sell ')); ?>

                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <a href="<?php echo e(route('asset_sells.create')); ?>" class="btn btn-primary d-none d-sm-inline-block">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19"/>
                                <line x1="5" y1="12" x2="19" y2="12"/>
                            </svg>
                            Create Asset Sell
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <?php if(config('tablar','display_alert')): ?>
                <?php echo $__env->make('tablar::common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="row row-deck row-cards">
                <div class="col-4">
                    <div class="card">
                        <div class="card-header py-1">
                            <h3 class="card-title fw-bolder">সম্পদ বিক্রয় ফরম</h3>
                        </div>
                        <?php
                            $assets = \App\Models\Asset::all();
                        ?>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('asset_sells.store')); ?>" id="ajaxForm" role="form"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-group mb-3">
                                    <label class="form-label">   <?php echo e(Form::label('asset_id','সম্পদ')); ?></label>
                                    <div>
                                        <select name="asset_id" id="aseet_id" class="select2 form-control <?php echo e(($errors->has('asset_id') ? ' is-invalid' : '')); ?>">
                                            <option value=""></option>
                                            <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($asset->id); ?>" <?php echo e(old('asset_id') == $asset->id?'selected':''); ?>><?php echo e($asset->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                        <?php echo $errors->first('asset_id', '<div class="invalid-feedback">:message</div>'); ?>

                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">   <?php echo e(Form::label('purchase_price','ক্রয় মূল্য')); ?></label>
                                    <div>
                                        <?php echo e(Form::text('purchase_price', old('purchase_price'), ['class' => 'form-control' .
                                        ($errors->has('purchase_price') ? ' is-invalid' : ''), 'placeholder' => 'Purchase Price'])); ?>

                                        <?php echo $errors->first('purchase_price', '<div class="invalid-feedback">:message</div>'); ?>

                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">   <?php echo e(Form::label('sale_price','বিক্রয় মূল্য')); ?></label>
                                    <div>
                                        <?php echo e(Form::text('sale_price', old('sale_price'), ['class' => 'form-control' .
                                        ($errors->has('sale_price') ? ' is-invalid' : ''), 'placeholder' => 'Sale Price'])); ?>

                                        <?php echo $errors->first('sale_price', '<div class="invalid-feedback">:message</div>'); ?>

                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">   <?php echo e(Form::label('date','তারিখ')); ?></label>
                                    <div>
                                        <?php echo e(Form::text('date', old('date'), ['class' => 'form-control flatpicker' .
                                        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

                                        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

                                    </div>
                                </div>
                                <?php
                                    use App\Models\Account;
                                    $accounts = Account::pluck('name','id');
                                ?>
                                <div class="form-group mb-3">
                                    <label>একাউন্ট</label>
                                    <select name="account_id" id="account_id" class="form-control select2" data-placeholder="সিলেক্ট একাউন্ট">
                                        <option value=""></option>
                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php echo e(old('account_id') == $key?'selected':''); ?>><?php echo e($account); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">   <?php echo e(Form::label('notes','নোট')); ?></label>
                                    <div>
                                        <?php echo e(Form::text('notes', old('notes'), ['class' => 'form-control' .
                                        ($errors->has('notes') ? ' is-invalid' : ''), 'placeholder' => 'Notes'])); ?>

                                        <?php echo $errors->first('notes', '<div class="invalid-feedback">:message</div>'); ?>

                                    </div>
                                </div>
                                <div class="form-footer">
                                    <div class="text-end">
                                        <div class="d-flex">
                                            <button type="submit" class="btn btn-primary ms-auto ajax-submit">সাবমিট</button>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-8">
                    <div class="card">
                        <div class="card-header py-1">
                            <h3 class="card-title fw-bolder">সম্পদ বিক্রয় তালিকা</h3>
                        </div>
                        <div class="table-responsive min-vh-100">
                            <table class="table card-table table- table-bordered text-nowrap datatable">
                                <tr>
                                    <th>তারিখ</th>
                                    <th>সম্পদ</th>
                                    <th>ক্রয় মুূল্য</th>
                                    <th>বিক্রয় মূল্য</th>
                                    <th>ব্যালেন্স</th>
                                    <th>নোট</th>
                                    <th class="w-1"></th>
                                </tr>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $assetSells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetSell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(date('d/m/Y',strtotime($assetSell->date))); ?></td>
                                        <td><?php echo e($assetSell->asset->name); ?></td>
                                        <td><?php echo e($assetSell->purchase_price); ?></td>
                                        <td><?php echo e($assetSell->sale_price); ?></td>
                                        <td><?php echo e($assetSell->balance); ?></td>
                                        <td><?php echo e($assetSell->notes); ?></td>
                                        <td>
                                            <div class="btn-list flex-nowrap">
                                                <div class="dropdown">
                                                    <button class="btn dropdown-toggle align-text-top"
                                                            data-bs-toggle="dropdown">
                                                        Actions
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('asset_sells.show',$assetSell->id)); ?>">
                                                            View
                                                        </a>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('asset_sells.edit',$assetSell->id)); ?>">
                                                            Edit
                                                        </a>
                                                        <form
                                                            action="<?php echo e(route('asset_sells.destroy',$assetSell->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                    onclick="if(!confirm('Do you Want to Proceed?')){return false;}"
                                                                    class="dropdown-item text-red"><i
                                                                    class="fa fa-fw fa-trash"></i>
                                                                Delete
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td>No Data Found</td>
                                <?php endif; ?>
                                </tbody>

                            </table>
                        </div>
                        <div class="card-footer d-flex align-items-center">
                            <?php echo $assetSells->links('tablar::pagination'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="module">
        document.addEventListener('DOMContentLoaded', function () {
            window.flatpickr(".flatpicker", {
                altInput: true,
                allowInput: true,
                altFormat: "d-m-Y",
                dateFormat: "Y-m-d",
                defaultDate: "<?php echo e(date('Y-m-d')); ?>"
            });
        });
    </script>

    <script type="module">
        $(".select2").select2({
            theme: "bootstrap-5",
            width: "100%",
            placeholder: "সিলেক্ট করুন"
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('tablar::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chaler_arot\resources\views/asset-sell/index.blade.php ENDPATH**/ ?>