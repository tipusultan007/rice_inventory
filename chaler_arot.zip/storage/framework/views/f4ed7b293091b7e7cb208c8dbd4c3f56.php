<footer class="footer footer-transparent d-print-none">
    <div class="container-xl">
        <div class="row text-center align-items-center flex-row-reverse">
            
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <div class="text-center">&copy; 2024 মেসার্স এস.এ রাইচ এজেন্সী। Developed by
                    <a target="_blank" href="https://umairit.com"
                       class="link-secondary">Umair IT</a>.</div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/vendor/tablar/partials/footer/bottom.blade.php ENDPATH**/ ?>