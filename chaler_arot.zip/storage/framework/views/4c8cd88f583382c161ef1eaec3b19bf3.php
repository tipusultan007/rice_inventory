
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('name')); ?></label>
    <div>
        <?php echo e(Form::text('name', $incomeCategory->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">incomeCategory <b>name</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/income-category/form.blade.php ENDPATH**/ ?>