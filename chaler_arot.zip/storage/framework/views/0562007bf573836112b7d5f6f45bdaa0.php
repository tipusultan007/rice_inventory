<?php $__env->startSection('title'); ?>
    সরবরাহকারী'র লেনদেন
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">

                    <h2 class="page-title">
                        সরবরাহকারী'র লেনদেন
                    </h2>
                </div>
                <!-- Page title actions -->
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <?php if(config('tablar','display_alert')): ?>
                <?php echo $__env->make('tablar::common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title fw-bolder">সরবরাহকারী'র পেমেন্ট ফরম</h3>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('transactions.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label" for="supplier_id">সরবরাহকারী</label>
                                            <select name="supplier_id" id="supplier_id"
                                                    class="form-control select2" required>
                                                <option value=""></option>
                                                <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option data-due="<?php echo e($supplier->remaining_due); ?>" value="<?php echo e($supplier->id); ?>">
                                                        <?php echo e($supplier->name); ?> - <?php echo e($supplier->address); ?> - <?php echo e($supplier->remaining_due); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <input type="hidden" name="transaction_type" value="supplier_payment">
                                        <input type="hidden" name="type" value="debit">
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label" for="amount">টাকা</label>
                                            <input type="number" class="form-control" name="amount" value="" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label" for="date">তারিখ</label>
                                            <input type="text" class="form-control flatpicker" name="date" required>
                                        </div>
                                        <div class="col-md-4 mb-3">

                                            <label class="form-label" for="account_id">পেমেন্ট মাধ্যম</label>
                                            <select name="account_id"
                                                    class="form-control select2" required>
                                                <option value=""></option>
                                                <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label" for="note">নোট</label>
                                            <input type="text" name="note" id="note" class="form-control">
                                        </div>
                                        <div class="col-md-2 mb-3 d-flex align-items-end">
                                            <button class="btn btn-primary w-100" type="submit">সাবমিট</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="table-responsive min-vh-100">
                            <table class="table card-table table-vcenter table-sm table-bordered datatable">
                                <thead>
                                <tr>
                                    <th class="fs-4">সরবরাহকারী</th>
                                    <th class="text-center fs-4">লেনদেন ধরন</th>
                                    <th class="fs-4">অ্যাকাউন্ট</th>
                                    <th class="fs-4">টাকা</th>
                                    <th class="text-center fs-4">ধরন</th>
                                    <th class="fs-4">তারিখ</th>
                                    <th class="w-1 fs-4"></th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($transaction->supplier->name??'-'); ?></td>
                                        <td class="text-center">
                                            <?php echo e($transaction->transaction_type); ?>

                                        </td>
                                        <td><?php echo e($transaction->account->name??'-'); ?></td>
                                        <td><?php echo e($transaction->amount); ?></td>
                                        <td class="text-center">
                                            <?php if($transaction->type === 'credit'): ?>
                                                <span class="badge bg-danger text-white">বকেয়া</span>
                                            <?php else: ?>
                                                <span class="badge bg-success text-white">পরিশোধ</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(date('d/m/Y',strtotime($transaction->created_at))); ?></td>
                                        <td>
                                            <div class="btn-list flex-nowrap">
                                                <div class="dropdown">
                                                    <button class="btn dropdown-toggle align-text-top"
                                                            data-bs-toggle="dropdown">
                                                        Actions
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('transactions.show',$transaction->id)); ?>">
                                                            View
                                                        </a>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('transactions.edit',$transaction->id)); ?>">
                                                            Edit
                                                        </a>
                                                        <form
                                                            action="<?php echo e(route('transactions.destroy',$transaction->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                    onclick="if(!confirm('Do you Want to Proceed?')){return false;}"
                                                                    class="dropdown-item text-red"><i
                                                                    class="fa fa-fw fa-trash"></i>
                                                                Delete
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td>No Data Found</td>
                                <?php endif; ?>
                                </tbody>

                            </table>
                        </div>
                        <div class="card-footer d-flex align-items-center">
                            <?php echo $transactions->links('tablar::pagination'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="module">
        $(document).ready(function () {
            $(".select2").select2({
                width: '100%',
                theme: 'bootstrap-5',
                allowClear: true,
                placeholder: 'সিলেক্ট করুন'
            });

        })
    </script>
    <script type="module">
        document.addEventListener('DOMContentLoaded', function () {
            window.flatpickr(".flatpicker", {
                altInput: true,
                allowInput: true,
                altFormat: "d-m-Y",
                dateFormat: "Y-m-d",
                defaultDate: "<?php echo e(date('Y-m-d')); ?>"
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tablar::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chaler_arot\resources\views/transaction/supplier.blade.php ENDPATH**/ ?>