<div class="form-group mb-3">
    <label class="form-label">  নাম</label>
    <div>
        <?php echo e(Form::text('name', $capital->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Loan Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('amount','মূলধনের পরিমাণ')); ?></label>
    <div>
        <?php echo e(Form::text('amount', $capital->amount, ['class' => 'form-control' .
        ($errors->has('amount') ? ' is-invalid' : ''), 'placeholder' => 'Amount'])); ?>

        <?php echo $errors->first('amount', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('profit_rate','লভ্যাংশ রেট')); ?></label>
    <div>
        <?php echo e(Form::text('profit_rate', $capital->profit_rate, ['class' => 'form-control' .
        ($errors->has('profit_rate') ? ' is-invalid' : ''), 'placeholder' => 'Profit Rate'])); ?>

        <?php echo $errors->first('profit_rate', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<?php
    use App\Models\Account;
    $accounts = Account::pluck('name','id');
?>
<div class="form-group mb-3">
    <label>একাউন্ট</label>
    <select name="account_id" id="account_id" class="form-control select2" data-placeholder="সিলেক্ট একাউন্ট">
        <option value=""></option>
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e(isset($creditTransaction)?$creditTransaction->account_id == $key?'selected':'':''); ?>><?php echo e($account); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('date','তারিখ')); ?></label>
    <div>
        <?php echo e(Form::text('date', $capital->date, ['class' => 'form-control flatpicker' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('description','বিবরণ')); ?></label>
    <div>
        <?php echo e(Form::text('description', $capital->description, ['class' => 'form-control' .
        ($errors->has('description') ? ' is-invalid' : ''), 'placeholder' => 'Description'])); ?>

        <?php echo $errors->first('description', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">সাবমিট</button>
            </div>
        </div>
    </div>
<script type="module">
    document.addEventListener('DOMContentLoaded', function () {
        window.flatpickr(".flatpicker", {
            altInput: true,
            allowInput: true,
            altFormat: "d-m-Y",
            dateFormat: "Y-m-d",
            defaultDate: "<?php echo e($capital->date != ""?$capital->date:date('Y-m-d')); ?>"
        });
    });
</script>

<script type="module">
    $(".select2").select2({
        theme: "bootstrap-5",
        width: "100%",
        placeholder: "একাউন্ট সিলেক্ট করুন"
    });
</script>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/capital/form.blade.php ENDPATH**/ ?>