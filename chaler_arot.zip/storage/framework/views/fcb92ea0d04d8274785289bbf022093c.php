<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type' => 'info']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => 'info']); ?>
<?php foreach (array_filter((['type' => 'info']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div <?php echo e($attributes->merge(['class' => 'card '])); ?>>

    <?php if(isset($stamp)): ?>
        <?php if (isset($component)) { $__componentOriginal1adde43b2df2ae90383a9ec1ea1b8bde = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1adde43b2df2ae90383a9ec1ea1b8bde = $attributes; } ?>
<?php $component = Takielias\TablarKit\Components\Cards\CardStamp::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-stamp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Takielias\TablarKit\Components\Cards\CardStamp::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php echo e($stamp); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1adde43b2df2ae90383a9ec1ea1b8bde)): ?>
<?php $attributes = $__attributesOriginal1adde43b2df2ae90383a9ec1ea1b8bde; ?>
<?php unset($__attributesOriginal1adde43b2df2ae90383a9ec1ea1b8bde); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1adde43b2df2ae90383a9ec1ea1b8bde)): ?>
<?php $component = $__componentOriginal1adde43b2df2ae90383a9ec1ea1b8bde; ?>
<?php unset($__componentOriginal1adde43b2df2ae90383a9ec1ea1b8bde); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if(isset($ribbon)): ?>
        <?php echo e($ribbon); ?>

    <?php endif; ?>

    <?php if(isset($header)): ?>
        <?php if (isset($component)) { $__componentOriginaldc516fac719f3e5a960e014468b4f638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc516fac719f3e5a960e014468b4f638 = $attributes; } ?>
<?php $component = Takielias\TablarKit\Components\Cards\CardHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Takielias\TablarKit\Components\Cards\CardHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php echo e($header); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc516fac719f3e5a960e014468b4f638)): ?>
<?php $attributes = $__attributesOriginaldc516fac719f3e5a960e014468b4f638; ?>
<?php unset($__attributesOriginaldc516fac719f3e5a960e014468b4f638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc516fac719f3e5a960e014468b4f638)): ?>
<?php $component = $__componentOriginaldc516fac719f3e5a960e014468b4f638; ?>
<?php unset($__componentOriginaldc516fac719f3e5a960e014468b4f638); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if(isset($body)): ?>
        <?php if (isset($component)) { $__componentOriginal5e0865a0f601d550dbc2a3a369f8d55b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e0865a0f601d550dbc2a3a369f8d55b = $attributes; } ?>
<?php $component = Takielias\TablarKit\Components\Cards\CardBody::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Takielias\TablarKit\Components\Cards\CardBody::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php echo e($body); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e0865a0f601d550dbc2a3a369f8d55b)): ?>
<?php $attributes = $__attributesOriginal5e0865a0f601d550dbc2a3a369f8d55b; ?>
<?php unset($__attributesOriginal5e0865a0f601d550dbc2a3a369f8d55b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e0865a0f601d550dbc2a3a369f8d55b)): ?>
<?php $component = $__componentOriginal5e0865a0f601d550dbc2a3a369f8d55b; ?>
<?php unset($__componentOriginal5e0865a0f601d550dbc2a3a369f8d55b); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if(isset($footer)): ?>
        <?php if (isset($component)) { $__componentOriginal075c43e08ee2a3c88a4cf42526774737 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal075c43e08ee2a3c88a4cf42526774737 = $attributes; } ?>
<?php $component = Takielias\TablarKit\Components\Cards\CardFooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Takielias\TablarKit\Components\Cards\CardFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php echo e($footer); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal075c43e08ee2a3c88a4cf42526774737)): ?>
<?php $attributes = $__attributesOriginal075c43e08ee2a3c88a4cf42526774737; ?>
<?php unset($__attributesOriginal075c43e08ee2a3c88a4cf42526774737); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal075c43e08ee2a3c88a4cf42526774737)): ?>
<?php $component = $__componentOriginal075c43e08ee2a3c88a4cf42526774737; ?>
<?php unset($__componentOriginal075c43e08ee2a3c88a4cf42526774737); ?>
<?php endif; ?>
    <?php endif; ?>

</div>
<?php /**PATH C:\wamp64\www\chaler_arot\vendor\takielias\tablar-kit\src/../resources/views/components/cards/card.blade.php ENDPATH**/ ?>