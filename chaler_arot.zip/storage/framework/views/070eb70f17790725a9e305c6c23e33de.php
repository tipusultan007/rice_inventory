<?php
    use App\Models\Account;
    $accounts = Account::pluck('name','id');
?>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('date','তারিখ')); ?></label>
    <div>
        <?php echo e(Form::text('date', $capitalWithdraw->date, ['class' => 'form-control flatpicker' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('amount','উত্তোলন')); ?></label>
    <div>
        <?php echo e(Form::text('amount', $capitalWithdraw->amount, ['class' => 'form-control' .
        ($errors->has('amount') ? ' is-invalid' : ''), 'placeholder' => 'Amount'])); ?>

        <?php echo $errors->first('amount', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('interest','মুনাফা')); ?></label>
    <div>
        <?php echo e(Form::text('interest', $capitalWithdraw->interest, ['class' => 'form-control' .
        ($errors->has('interest') ? ' is-invalid' : ''), 'placeholder' => 'Interest'])); ?>

        <?php echo $errors->first('interest', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<div class="form-group mb-3">
    <select name="account_id" id="account_id" class="form-control select2"
            data-placeholder="অ্যাকাউন্ট">
        <option value=""></option>
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e($transaction->account_id == $key ? 'selected':''); ?>><?php echo e($account); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">সাবমিট</button>
            </div>
        </div>
    </div>
<script type="module">
    $(".select2").select2({
        theme: "bootstrap-5",
        width: "100%",
        placeholder: "একাউন্ট সিলেক্ট করুন"
    });
</script>
<script type="module">
    document.addEventListener('DOMContentLoaded', function () {
        window.flatpickr(".flatpicker", {
            altInput: true,
            allowInput: true,
            altFormat: "d-m-Y",
            dateFormat: "Y-m-d",
            defaultDate: "<?php echo e($capitalWithdraw->date); ?>"
        });
    });
</script>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/capital-withdraw/form.blade.php ENDPATH**/ ?>