
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('employee_id','কর্মীর নাম')); ?></label>
    <div>
        <select name="employee_id" id="employee_id"
                class="form-control select2" required>
            <option value=""></option>
            <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($employee->id); ?>" <?php echo e($employee->id == $salary->employee_id?'selected':''); ?>>
                    <?php echo e($employee->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('amount','টাকা')); ?></label>
    <div>
        <?php echo e(Form::text('amount', $salary->amount, ['class' => 'form-control' .
        ($errors->has('amount') ? ' is-invalid' : ''), 'placeholder' => 'Amount'])); ?>

        <?php echo $errors->first('amount', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('date','তারিখ')); ?></label>
    <div>
        <?php echo e(Form::text('date', $salary->date, ['class' => 'form-control flatpicker' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label" for="account_id">অ্যাকাউন্ট</label>
    <select name="account_id"
            class="form-control select2" required>
        <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($account->id); ?>" <?php echo e(isset($creditTransaction)?$creditTransaction->account_id == $account->id?'selected':'':''); ?>><?php echo e($account->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </select>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <button type="submit" class="btn btn-primary ms-auto ajax-submit" id="submitButton">সাবমিট</button>
            </div>
        </div>
    </div>

<script type="module">
    $(document).ready(function () {
        $(".select2").select2({
            width: '100%',
            theme: 'bootstrap-5',
            allowClear: true,
            placeholder: 'সিলেক্ট করুন'
        });
    })
</script>
<script type="module">
    document.addEventListener('DOMContentLoaded', function () {
        window.flatpickr(".flatpicker", {
            altInput: true,
            allowInput: true,
            altFormat: "d-m-Y",
            dateFormat: "Y-m-d",
            defaultDate: "<?php echo e($salary?$salary->date:date('Y-m-d')); ?>"
        });
    });
</script>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/salary/form.blade.php ENDPATH**/ ?>