<div class="row">
    <div class="form-group col-3 mb-3">
        <label class="form-label">   <?php echo e(Form::label('name','নাম')); ?></label>
        <div>
            <?php echo e(Form::text('name', $investment->name, ['class' => 'form-control' .
            ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>
    <div class="form-group col-3 mb-3">
        <label class="form-label">   <?php echo e(Form::label('loan_amount','ঋনের পরিমাণ')); ?></label>
        <div>
            <?php echo e(Form::text('loan_amount', $investment->loan_amount, ['class' => 'form-control' .
            ($errors->has('loan_amount') ? ' is-invalid' : ''), 'placeholder' => 'Loan Amount'])); ?>

            <?php echo $errors->first('loan_amount', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>
    <div class="form-group col-3 mb-3">
        <label class="form-label">   <?php echo e(Form::label('interest_rate','সুদের হার')); ?></label>
        <div>
            <?php echo e(Form::text('interest_rate', $investment->interest_rate, ['class' => 'form-control' .
            ($errors->has('interest_rate') ? ' is-invalid' : ''), 'placeholder' => 'Interest Rate'])); ?>

            <?php echo $errors->first('interest_rate', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>
    <div class="form-group col-3 mb-3">
        <label class="form-label">   <?php echo e(Form::label('grace','ছাড়')); ?></label>
        <div>
            <?php echo e(Form::text('grace', $investment->grace, ['class' => 'form-control' .
            ($errors->has('grace') ? ' is-invalid' : ''), 'placeholder' => 'Grace'])); ?>

            <?php echo $errors->first('grace', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>


    <div class="form-group mb-3 col-4">
        <label class="form-label">   <?php echo e(Form::label('date','তারিখ')); ?></label>
        <div>
            <?php echo e(Form::text('date', $investment->date, ['class' => 'form-control flatpicker' .
            ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

            <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>

    <div class="form-group mb-3 col-4">
        <label class="form-label">   <?php echo e(Form::label('description','বিবরন')); ?></label>
        <div>
            <?php echo e(Form::text('description', $investment->description, ['class' => 'form-control' .
            ($errors->has('description') ? ' is-invalid' : ''), 'placeholder' => 'Description'])); ?>

            <?php echo $errors->first('description', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>
    <?php
        use App\Models\Account;
        $accounts = Account::pluck('name','id');
    ?>
    <div class="form-group mb-3 col-4">
        <label for="" class="form-label">একাউন্ট তালিকা</label>
        <select name="account_id" id="account_id" class="form-control select2"
                data-placeholder="সিলেক্ট একাউন্ট">
            <option value=""></option>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"><?php echo e($account); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>


    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">সাবমিট</button>
            </div>
        </div>
    </div>
<script type="module">
    $(".select2").select2({
        theme: "bootstrap-5",
        width: "100%",
        placeholder: "একাউন্ট সিলেক্ট করুন"
    });
</script>
<script type="module">
    document.addEventListener('DOMContentLoaded', function () {
        window.flatpickr(".flatpicker", {
            altInput: true,
            allowInput: true,
            altFormat: "d-m-Y",
            dateFormat: "Y-m-d",
            defaultDate: "<?php echo e($investment->date); ?>"
        });
    });
</script>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/investment/form.blade.php ENDPATH**/ ?>