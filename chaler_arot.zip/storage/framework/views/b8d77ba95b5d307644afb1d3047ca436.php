
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('purchase_price','ক্রয় মূল্য')); ?></label>
    <div>
        <?php echo e(Form::text('purchase_price', $assetSell->purchase_price, ['class' => 'form-control' .
        ($errors->has('purchase_price') ? ' is-invalid' : ''), 'placeholder' => 'Purchase Price'])); ?>

        <?php echo $errors->first('purchase_price', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('sale_price','বিক্রয় মূল্য')); ?></label>
    <div>
        <?php echo e(Form::text('sale_price', $assetSell->sale_price, ['class' => 'form-control' .
        ($errors->has('sale_price') ? ' is-invalid' : ''), 'placeholder' => 'Sale Price'])); ?>

        <?php echo $errors->first('sale_price', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('notes','নোট')); ?></label>
    <div>
        <?php echo e(Form::text('notes', $assetSell->notes, ['class' => 'form-control' .
        ($errors->has('notes') ? ' is-invalid' : ''), 'placeholder' => 'Notes'])); ?>

        <?php echo $errors->first('notes', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('date','তারিখ')); ?></label>
    <div>
        <?php echo e(Form::text('date', $assetSell->date, ['class' => 'form-control' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>
<?php
    use App\Models\Account;
    $accounts = Account::pluck('name','id');
?>
<div class="form-group mb-3">
    <label>একাউন্ট</label>
    <select name="account_id" id="account_id" class="form-control select2" data-placeholder="সিলেক্ট একাউন্ট">
        <option value=""></option>
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e($assetSell->account_id == $key?'selected':''); ?>><?php echo e($account); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">সাবমিট</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/asset-sell/form.blade.php ENDPATH**/ ?>