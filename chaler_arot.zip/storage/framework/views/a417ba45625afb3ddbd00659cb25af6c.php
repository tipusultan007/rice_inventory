<?php $__env->startSection('title'); ?>
    দৈনিক রিপোর্ট
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <h2 class="page-title">
                        দৈনিক রিপোর্ট
                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <button class="btn btn-primary d-none d-sm-inline-block" onclick="window.print()">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path
                                    d="M17 17h2a2 2 0 0 0 2 -2v-4a2 2 0 0 0 -2 -2h-14a2 2 0 0 0 -2 2v4a2 2 0 0 0 2 2h2"></path>
                                <path d="M17 9v-4a2 2 0 0 0 -2 -2h-6a2 2 0 0 0 -2 2v4"></path>
                                <path
                                    d="M7 13m0 2a2 2 0 0 1 2 -2h6a2 2 0 0 1 2 2v4a2 2 0 0 1 -2 2h-6a2 2 0 0 1 -2 -2z"></path>
                            </svg>
                            প্রিন্ট করুন
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <?php if(config('tablar','display_alert')): ?>
                <?php echo $__env->make('tablar::common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="row">
                <div class="col-12 justify-content-center">
                        <div class="info text-center">
                            <h1 class="display-6 fw-bolder mb-1">মেসার্স এস.এ রাইচ এজেন্সী</h1>
                            <span class="badge badge-outline text-gray fs-3">দৈনিক রিপোর্ট</span>
                            <h3 class="mt-2">তারিখঃ <?php echo e(date('d/m/Y')); ?></h3>
                        </div>
                </div>
                <div class="col-12 d-print-none">
                    <form action="<?php echo e(route('report.daily')); ?>" method="get">
                        <div class="row">
                            <div class="col-md-2">
                                <input type="text" class="form-control flatpicker" name="date">
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-secondary" type="submit">সার্চ করুন</button>
                            </div>
                        </div>
                    </form>
                </div>
               
            </div>
                <?php
                    $total_debit = 0;
                    $total_credit = 0;
                ?>
                <div class="row">
                    <div class="col-12">
                        <hr>
                        <h3 class="text-center">দৈনিক লেনদেন</h3>
                        <hr>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-body">
                                <table class="table table-bordered table-sm">
                                    <thead>
                                    <tr>
                                        <th class="fs-3 fw-bolder">অ্যাকাউন্ট</th>
                                        <th class="fs-3 fw-bolder">ডেবিট</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $debitTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $total_debit +=$transaction->total_debit;
                                        ?>
                                        <tr>
                                            <td><?php echo e($transaction->account_name); ?></td>
                                            <td class="text-end"><?php echo e(number_format($transaction->total_debit)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="text-end fs-3">মোট =</th>
                                            <th class="text-end fs-3"><?php echo e(number_format($total_debit)); ?></th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-body">
                                <table class="table table-bordered table-sm">
                                    <thead>
                                    <tr>
                                        <th class="fs-3 fw-bolder">অ্যাকাউন্ট</th>
                                        <th class="fs-3 fw-bolder">ক্রেডিট</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $creditTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $total_credit +=$transaction->total_credit;
                                        ?>
                                        <tr>
                                            <td><?php echo e($transaction->account_name); ?></td>
                                            <td class="text-end"><?php echo e(number_format($transaction->total_credit)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th class="text-end fs-3">মোট =</th>
                                        <th class="text-end fs-3"><?php echo e(number_format($total_credit)); ?></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-12">
                        <hr>
                        <h3 class="text-center">ক্রয়-বিক্রয়</h3>
                        <hr>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <table class="table table-sm table-bordered">
                                <caption style="caption-side: top;" class="fw-bolder text-center py-1">ক্রয়</caption>
                                <tr>
                                    <th>সরবরাহকারী</th>
                                    <th class="text-end">পরিমাণ</th>
                                    <th class="text-end">সর্বমোট</th>
                                    <th class="text-end">পরিশোধ</th>
                                    <th>চালান</th>
                                </tr>
                                <?php
                                $purchase_quantity = 0;
                                 ?>
                               <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $purchase_quantity += $purchase->purchaseDetails->sum('quantity');
                                    ?>
                                   <tr>
                                       <td><?php echo e($purchase->supplier->name); ?></td>
                                       <td class="text-end"><?php echo e($purchase->purchaseDetails->sum('quantity')); ?></td>
                                       <td class="text-end"><?php echo e(number_format($purchase->total)); ?></td>
                                       <td class="text-end"><?php echo e(number_format($purchase->paid)); ?></td>
                                       <td>
                                           <a href="<?php echo e(route('purchases.show', $purchase->id)); ?>" class="btn btn-sm btn-primary">দেখুন</a>
                                       </td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-end">মোট =</th>
                                    <th class="text-end"><?php echo e($purchase_quantity); ?></th>
                                    <th class="text-end"><?php echo e($purchases->sum('total')); ?></th>
                                    <th class="text-end"><?php echo e($purchases->sum('paid')); ?></th>
                                    <th></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <table class="table table-sm table-bordered">
                                <caption style="caption-side: top;" class="fw-bolder text-center py-1">বিক্রয়</caption>
                                <tr>
                                    <th>ক্রেতা</th>
                                    <th class="text-end">পরিমাণ</th>
                                    <th class="text-end">সর্বমোট</th>
                                    <th class="text-end">পরিশোধ</th>
                                    <th>চালান</th>
                                </tr>
                                <?php
                                    $sale_quantity = 0;
                                ?>
                                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $sale_quantity += $sale->saleDetails->sum('quantity');
                                    ?>
                                    <tr>
                                        <td><?php echo e($sale->customer->name); ?></td>
                                        <td class="text-end"><?php echo e($sale->saleDetails->sum('quantity')); ?></td>
                                        <td class="text-end"><?php echo e(number_format($sale->total)); ?></td>
                                        <td class="text-end"><?php echo e(number_format($sale->paid)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('sales.show', $sale->id)); ?>" class="btn btn-sm btn-primary">দেখুন</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-end">মোট =</th>
                                    <th class="text-end"><?php echo e($sale_quantity); ?></th>
                                    <th class="text-end"><?php echo e($sales->sum('total')); ?></th>
                                    <th class="text-end"><?php echo e($sales->sum('paid')); ?></th>
                                    <th></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="row my-3">
                    <div class="col-12">
                        <hr>
                        <h3 class="text-center">ক্রয় ফেরত - বিক্রয় ফেরত</h3>
                        <hr>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <table class="table table-sm table-bordered">
                                <caption style="caption-side: top;" class="fw-bolder text-center py-1">ক্রয়</caption>
                                <tr>
                                    <th>সরবরাহকারী</th>
                                    <th class="text-end">পরিমাণ</th>
                                    <th class="text-end">সর্বমোট</th>
                                    <th class="text-end">পরিশোধ</th>
                                    <th>চালান</th>
                                </tr>
                                <?php
                                    $purchaseReturn_quantity = 0;
                                ?>
                                <?php $__currentLoopData = $purchaseReturns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseReturn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $purchaseReturn_quantity += $purchaseReturn->purchaseReturnDetail->sum('quantity');
                                    ?>
                                    <tr>
                                        <td><?php echo e($purchaseReturn->supplier->name); ?></td>
                                        <td class="text-end"><?php echo e($purchaseReturn->purchaseReturnDetail->sum('quantity')); ?></td>
                                        <td class="text-end"><?php echo e(number_format($purchaseReturn->total)); ?></td>
                                        <td class="text-end"><?php echo e(number_format($purchaseReturn->paid)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('purchase_returns.show', $purchaseReturn->id)); ?>" class="btn btn-sm btn-primary">দেখুন</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-end">মোট =</th>
                                    <th class="text-end"><?php echo e($purchaseReturn_quantity); ?></th>
                                    <th class="text-end"><?php echo e($purchaseReturns->sum('total')); ?></th>
                                    <th class="text-end"><?php echo e($purchaseReturns->sum('paid')); ?></th>
                                    <th></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <table class="table table-sm table-bordered">
                                <caption style="caption-side: top;" class="fw-bolder text-center py-1">বিক্রয়</caption>
                                <tr>
                                    <th>ক্রেতা</th>
                                    <th class="text-end">পরিমাণ</th>
                                    <th class="text-end">সর্বমোট</th>
                                    <th class="text-end">পরিশোধ</th>
                                    <th>চালান</th>
                                </tr>
                                <?php
                                    $saleReturn_quantity = 0;
                                ?>
                                <?php $__currentLoopData = $saleReturns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saleReturn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $saleReturn_quantity += $saleReturn->saleReturnDetail->sum('quantity');
                                    ?>
                                    <tr>
                                        <td><?php echo e($saleReturn->customer->name); ?></td>
                                        <td class="text-end"><?php echo e($saleReturn->saleReturnDetail->sum('quantity')); ?></td>
                                        <td class="text-end"><?php echo e(number_format($saleReturn->total)); ?></td>
                                        <td class="text-end"><?php echo e(number_format($saleReturn->paid)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('sale_returns.show', $saleReturn->id)); ?>" class="btn btn-sm btn-primary">দেখুন</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-end">মোট =</th>
                                    <th class="text-end"><?php echo e($saleReturn_quantity); ?></th>
                                    <th class="text-end"><?php echo e($saleReturns->sum('total')); ?></th>
                                    <th class="text-end"><?php echo e($saleReturns->sum('paid')); ?></th>
                                    <th></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-12">
                        <hr>
                        <h3 class="text-center">আয়-ব্যয় হিসাব</h3>
                        <hr>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <table class="table table-sm table-bordered">
                                <caption class="fw-bolder text-center py-1" style="caption-side: top">ব্যয়</caption>
                                <tr>
                                    <th>ক্যাটেগরি</th>
                                    <th class="text-end">টাকা</th>
                                </tr>
                                <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($expense->category); ?></td>
                                        <td class="text-end"><?php echo e(number_format($expense->total)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-end">মোট =</th>
                                    <th class="text-end"><?php echo e($expenses->sum('total')); ?></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <table class="table table-sm table-bordered">
                                <caption class="fw-bolder text-center py-1" style="caption-side: top">আয়</caption>
                                <tr>
                                    <th>ক্যাটেগরি</th>
                                    <th class="text-end">টাকা</th>
                                </tr>
                                <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($income->category); ?></td>
                                        <td class="text-end"><?php echo e(number_format($income->total)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-end">মোট =</th>
                                    <th class="text-end"><?php echo e($incomes->sum('total')); ?></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <?php
                    $total25 = 0;
                    $total50 = 0;
                    $totalValue50 = 0;
                    $totalValue25 = 0;
                ?>

                <div class="row my-3">
                    <div class="col-12">
                        <hr>
                        <h3 class="text-center">পণ্য স্টক</h3>
                        <hr>
                    </div>
                    <div class="col-6">
                        <table class="table table-bordered table-vcenter table-sm">
                            <caption class="py-1" style="caption-side: top; font-weight: bold;text-align: center">২৫ কেজি বস্তা</caption>
                            <thead>
                            <tr>
                                <th class="fw-bolder fs-5">বিবরণ</th>
                                <th class="fw-bolder fs-5 text-end">পরিমাণ</th>
                                <th class="fw-bolder fs-5 text-end">বর্তমান মূল্য</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $productData25; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total25 += $data['quantity'];
                                    $totalValue25 += ($data['price_rate'] * $data['quantity']);
                                ?>
                                <tr>
                                    <td><?php echo e($data['product_name']); ?></td>
                                    <td class="text-end"><?php echo e($data['quantity']); ?></td>
                                    <td class="text-end"><?php echo e($data['price_rate'] * $data['quantity']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                            <tfoot>
                            <tr>
                                <th class="text-end">মোট =</th>
                                <th class="text-end"><?php echo e($total25); ?></th>
                                <th class="text-end"><?php echo e($totalValue25); ?></th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="col-6">
                        <table class="table table-sm table-vcenter table-bordered">
                            <caption class="py-1" style="caption-side: top; font-weight: bold;text-align: center">৫০ কেজি বস্তা</caption>
                            <thead>
                            <tr>
                                <th class="fw-bolder fs-5">বিবরণ</th>
                                <th class="fw-bolder fs-5 text-end">পরিমাণ</th>
                                <th class="fw-bolder fs-5 text-end">বর্তমান মূল্য</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $productData50; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total50 += $data['quantity'];
                                    $totalValue50 += ($data['price_rate'] * $data['quantity']);
                                ?>
                                <tr>
                                    <td><?php echo e($data['product_name']); ?></td>
                                    <td class="text-end"><?php echo e($data['quantity']); ?></td>
                                    <td class="text-end"><?php echo e($data['price_rate'] * $data['quantity']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th class="text-end">মোট =</th>
                                <th class="text-end"><?php echo e($total50); ?></th>
                                <th class="text-end"><?php echo e($totalValue50); ?></th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-4">
                        <div class="card">
                            <table class="table table-sm table-bordered card-table">
                                <tr>
                                    <th>বিবরন</th>
                                    <th class="text-end">পরিমাণ</th>
                                    <th class="text-end">বর্তমান মূল্য</th>
                                </tr>
                                <tr>
                                    <td>২৫ কেজি বস্তা</td>
                                    <td class="text-end"><?php echo e($total25); ?></td>
                                    <td class="text-end"><?php echo e($totalValue25); ?></td>
                                </tr>
                                <tr>
                                    <td>৫০ কেজি বস্তা</td>
                                    <td class="text-end"><?php echo e($total50); ?></td>
                                    <td class="text-end"><?php echo e($totalValue50); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-end">মোট=</th>
                                    <th class="text-end"><?php echo e($total25 + $total50); ?></th>
                                    <th class="text-end"><?php echo e($totalValue25 + $totalValue50); ?></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="module">
        document.addEventListener('DOMContentLoaded', function () {
            window.flatpickr(".flatpicker", {
                altInput: true,
                allowInput: true,
                altFormat: "d-m-Y",
                dateFormat: "Y-m-d",
                defaultDate: "<?php echo e(date('Y-m-d')); ?>"
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tablar::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chaler_arot\resources\views/reports/daily.blade.php ENDPATH**/ ?>