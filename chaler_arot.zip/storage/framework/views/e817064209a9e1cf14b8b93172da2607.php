<div class="card-stamp">
        <!-- Download SVG icon from http://tabler-icons.io/i/star -->
        <?php echo e($slot); ?>

</div>
<?php /**PATH C:\wamp64\www\chaler_arot\vendor\takielias\tablar-kit\src/../resources/views/components/cards/stamp.blade.php ENDPATH**/ ?>