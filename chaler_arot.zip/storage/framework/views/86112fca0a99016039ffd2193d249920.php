<!-- Sidebar -->
<aside class="<?php echo e($layoutData['cssClasses'] ?? 'navbar navbar-vertical navbar-expand-lg'); ?> d-print-none"
       <?php if(config('tablar.layout_light_sidebar') !== null): ?>
           data-bs-theme="<?php echo e(config('tablar.layout_light_sidebar') ? 'light' : 'dark'); ?>"
    <?php endif; ?>
>
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar-menu"
                aria-controls="sidebar-menu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <h1 class="navbar-brand navbar-brand-autodark">
            <?php echo $__env->make('tablar::partials.common.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </h1>
        <div class="navbar-nav flex-row d-lg-none">
            <div class="nav-item d-none d-lg-flex me-3">
                <div class="btn-list">
                    <?php echo $__env->make('tablar::partials.header.header-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="d-none d-lg-flex">
                <?php echo $__env->make('tablar::partials.header.theme-mode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('tablar::partials.header.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php echo $__env->make('tablar::partials.header.top-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="collapse navbar-collapse" id="sidebar-menu">
            <ul class="navbar-nav pt-lg-3">
                <?php echo $__env->renderEach('tablar::partials.navbar.dropdown-item',$tablar->menu('sidebar'), 'item'); ?>
            </ul>
        </div>
    </div>
</aside>

<?php if(config('tablar.layout_enable_top_header')): ?>
    <?php echo $__env->make('tablar::partials.header.sidebar-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/vendor/tablar/partials/navbar/sidebar.blade.php ENDPATH**/ ?>