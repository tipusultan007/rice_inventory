
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('name')); ?></label>
    <div>
        <?php echo e(Form::text('name', $supplier->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">supplier <b>name</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('phone')); ?></label>
    <div>
        <?php echo e(Form::text('phone', $supplier->phone, ['class' => 'form-control' .
        ($errors->has('phone') ? ' is-invalid' : ''), 'placeholder' => 'Phone'])); ?>

        <?php echo $errors->first('phone', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">supplier <b>phone</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('address')); ?></label>
    <div>
        <?php echo e(Form::text('address', $supplier->address, ['class' => 'form-control' .
        ($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address'])); ?>

        <?php echo $errors->first('address', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">supplier <b>address</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('company')); ?></label>
    <div>
        <?php echo e(Form::text('company', $supplier->company, ['class' => 'form-control' .
        ($errors->has('company') ? ' is-invalid' : ''), 'placeholder' => 'Company'])); ?>

        <?php echo $errors->first('company', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">supplier <b>company</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/supplier/form.blade.php ENDPATH**/ ?>