
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('date')); ?></label>
    <div>
        <?php echo e(Form::text('date', $purchaseReturn->date, ['class' => 'form-control' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">purchaseReturn <b>date</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('purchase_id')); ?></label>
    <div>
        <?php echo e(Form::text('purchase_id', $purchaseReturn->purchase_id, ['class' => 'form-control' .
        ($errors->has('purchase_id') ? ' is-invalid' : ''), 'placeholder' => 'Purchase Id'])); ?>

        <?php echo $errors->first('purchase_id', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">purchaseReturn <b>purchase_id</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('supplier_id')); ?></label>
    <div>
        <?php echo e(Form::text('supplier_id', $purchaseReturn->supplier_id, ['class' => 'form-control' .
        ($errors->has('supplier_id') ? ' is-invalid' : ''), 'placeholder' => 'Supplier Id'])); ?>

        <?php echo $errors->first('supplier_id', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">purchaseReturn <b>supplier_id</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('user_id')); ?></label>
    <div>
        <?php echo e(Form::text('user_id', $purchaseReturn->user_id, ['class' => 'form-control' .
        ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id'])); ?>

        <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">purchaseReturn <b>user_id</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('total')); ?></label>
    <div>
        <?php echo e(Form::text('total', $purchaseReturn->total, ['class' => 'form-control' .
        ($errors->has('total') ? ' is-invalid' : ''), 'placeholder' => 'Total'])); ?>

        <?php echo $errors->first('total', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">purchaseReturn <b>total</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('note')); ?></label>
    <div>
        <?php echo e(Form::text('note', $purchaseReturn->note, ['class' => 'form-control' .
        ($errors->has('note') ? ' is-invalid' : ''), 'placeholder' => 'Note'])); ?>

        <?php echo $errors->first('note', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">purchaseReturn <b>note</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('attachment')); ?></label>
    <div>
        <?php echo e(Form::text('attachment', $purchaseReturn->attachment, ['class' => 'form-control' .
        ($errors->has('attachment') ? ' is-invalid' : ''), 'placeholder' => 'Attachment'])); ?>

        <?php echo $errors->first('attachment', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">purchaseReturn <b>attachment</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/purchase-return/form.blade.php ENDPATH**/ ?>