<?php $__env->startSection('title'); ?>
    Transaction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <h2 class="page-title">
                        লেনদেন
                    </h2>
                </div>

            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <?php if(config('tablar','display_alert')): ?>
                <?php echo $__env->make('tablar::common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="table-responsive min-vh-100">
                            <table class="table table-vcenter table-sm table-bordered datatable">
                                <thead>
                                <tr>
                                    <th class="fw-bolder fs-4">তারিখ</th>
                                    <th class="fw-bolder fs-4">বিবরণ</th>
                                    <th class="fw-bolder fs-4">অ্যাকাউন্ট</th>
                                    <th class="fw-bolder fs-4 text-end">ডেবিট</th>
                                    <th class="fw-bolder fs-4 text-end">ক্রেডিট</th>
                                    <th class="fw-bolder fs-4">নোট</th>
                                    <th class="fw-bolder fs-4 text-center">অ্যাকশন</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php
                                    $previousTrxId = null;
                                    $rowspan = 0;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($transaction->trx_id !== $previousTrxId): ?>
                                        <?php if($previousTrxId !== null): ?>
                                            <tr>
                                                <td colspan="7" class="py-3"></td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php
                                            $rowspan = 0;
                                        ?>
                                    <?php endif; ?>
                                    <tr>
                                        <td><?php echo e(date('d/m/Y',strtotime($transaction->date))); ?></td>
                                        <td><?php echo e(transactionType($transaction->transaction_type)); ?></td>
                                        <td><?php echo e($transaction->account_name); ?></td>
                                        <td class="text-end"><?php echo e($transaction->type === 'debit'?$transaction->amount:'-'); ?></td>
                                        <td class="text-end"><?php echo e($transaction->type === 'credit'?$transaction->amount:'-'); ?></td>
                                        <td><?php echo e($transaction->note??'-'); ?></td>
                                        <td class="text-center">
                                            <?php if($transaction->transaction_type === 'sale'): ?>
                                                <a class="btn btn-sm btn-primary" target="_blank" href="<?php echo e(route('sales.show',$transaction->reference_id)); ?>">মেমো</a>
                                            <?php elseif($transaction->transaction_type === 'purchase'): ?>
                                                <a class="btn btn-sm btn-primary" target="_blank" href="<?php echo e(route('purchases.show',$transaction->reference_id)); ?>">চালান</a>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                    <?php
                                        $previousTrxId = $transaction->trx_id;
                                        $rowspan++;
                                        $transaction->rowspan = $rowspan;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No transactions found.</td>
                                    </tr>
                                <?php endif; ?>
                                
                                </tbody>

                            </table>
                        </div>
                        <div class="card-footer d-flex align-items-center">
                            <?php echo $transactions->links('tablar::pagination'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tablar::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chaler_arot\resources\views/transaction/index.blade.php ENDPATH**/ ?>