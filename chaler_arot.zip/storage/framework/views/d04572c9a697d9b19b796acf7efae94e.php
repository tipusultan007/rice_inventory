<?php $__env->startSection('title'); ?>
    পেমেন্ট রিপোর্ট
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <h2 class="page-title">
                        পেমেন্ট রিপোর্ট
                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <button class="btn btn-primary d-none d-sm-inline-block" onclick="window.print()">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path
                                    d="M17 17h2a2 2 0 0 0 2 -2v-4a2 2 0 0 0 -2 -2h-14a2 2 0 0 0 -2 2v4a2 2 0 0 0 2 2h2"></path>
                                <path d="M17 9v-4a2 2 0 0 0 -2 -2h-6a2 2 0 0 0 -2 2v4"></path>
                                <path
                                    d="M7 13m0 2a2 2 0 0 1 2 -2h6a2 2 0 0 1 2 2v4a2 2 0 0 1 -2 2h-6a2 2 0 0 1 -2 -2z"></path>
                            </svg>
                            প্রিন্ট করুন
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->

    <div class="page-body">
        <div class="container-xl">
            <?php if(config('tablar','display_alert')): ?>
                <?php echo $__env->make('tablar::common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="row row-deck row-cards mb-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">পেমেন্ট ফিল্টার</h3>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('report.payment')); ?>" method="GET">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <select name="customer_id" id="customer_id" class="form-control select2" data-placeholder="ক্রেতা">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name.' - '.$customer->address); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-3 mb-3">
                                        <select name="supplier_id" id="supplier_id" class="form-control select2" data-placeholder="সরবরাহকারী">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name.' - '.$supplier->address); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <select name="account_id" id="account_id" class="form-control select2" data-placeholder="অ্যাকাউন্ট">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($method->id); ?>"><?php echo e($method->name.' - '.$method->address); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <select name="transaction_type" id="transaction_type" class="form-control select2" data-placeholder="লেনদেনের ধরন নির্বাচন করুন">
                                            <option value=""></option>
                                            <option value="balance_transfer_out">ব্যালেন্স ট্রান্সফার আউট</option>
                                            <option value="balance_transfer_in">ব্যালেন্স ট্রান্সফার ইন</option>
                                            <option value="balance_addition">ব্যালেন্স যোগ</option>
                                            <option value="external_payment_received">বাইরের পেমেন্ট প্রাপ্ত</option>
                                            <option value="external_payment_made">বাইরের পেমেন্ট করা</option>
                                            <option value="due_payment">বাকি পেমেন্ট</option>
                                            <option value="supplier_payment">সাপ্লাইয়ার পেমেন্ট</option>
                                            <option value="sale">বিক্রয়</option>
                                            <option value="purchase">ক্রয়</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <input type="text" class="form-control flatpicker" name="start_date" placeholder="শুরুর তারিখ">
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <input type="text" class="form-control flatpicker" name="end_date" placeholder="শেষ তারিখ">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <button class="btn btn-primary w-25" type="submit">সার্চ</button>
                                        <a href="<?php echo e(route('report.payment')); ?>" class="btn btn-secondary w-25">রিসেট</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php if($payments->count()>0): ?>
                            <div class="card">
                                <div class="card-body">
                                    <p>সার্চ রেজাল্টঃ</p>
                                    <ul>
                                        <?php if(!is_null($customer_id)): ?>
                                            <li><b>ক্রেতাঃ</b> <?php echo e($customers[$customer_id]->name); ?></li>
                                        <?php endif; ?>
                                        <?php if(!is_null($supplier_id)): ?>
                                            <li><b>সরবরাহকারীঃ</b> <?php echo e($suppliers[$supplier_id]->name); ?></li>
                                        <?php endif; ?>
                                        <?php if(!is_null($payment_method_id)): ?>
                                            <li><b>অ্যাকাউন্টঃ</b> <?php echo e($methods[$payment_method_id]->name); ?></li>
                                        <?php endif; ?>
                                        <?php if(!is_null($start_date)): ?>
                                            <li>শুরুর তারিখ: <?php echo e(date('d/m/Y',strtotime($start_date))); ?></li>
                                        <?php endif; ?>
                                        <?php if(!is_null($end_date)): ?>
                                            <li>শেষ তারিখ: <?php echo e(date('d/m/Y',strtotime($end_date))); ?></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">পেমেন্ট তালিকা</h3>
                        </div>

                        <table class="table card-table table-vcenter datatable table-bordered">
                            <thead>
                            <tr>
                                <th class="fw-bolder fs-4">তারিখ</th>
                                <th class="fw-bolder fs-4 bg-success text-white">ক্রেতা</th>
                                <th class="fw-bolder fs-4 bg-danger text-white">সরবরাহকারী</th>
                                <th class="fw-bolder fs-4">অ্যাকাউন্ট</th>
                                <th class="fw-bolder fs-4">পেমেন্ট'র ধরন</th>
                                <th class="fw-bolder fs-4">টাকা</th>
                                <th class="w-1"></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="py-1"><?php echo e(date('d/m/Y',strtotime($payment->date))); ?></td>
                                    <td class="py-1 bg-success text-white"><?php echo e($payment->customer->name??'-'); ?></td>
                                    <td class="py-1 bg-danger text-white"><?php echo e($payment->supplier->name??'-'); ?></td>
                                    <td class="py-1"><?php echo e($payment->account->name??'-'); ?></td>
                                    <td class="py-1">

                                        <?php if($payment->customer_id != ""): ?>
                                            <?php if($payment->type === 'debit'): ?>
                                                <span class="badge bg-danger text-white">বকেয়া</span>
                                            <?php elseif($payment->type === 'credit'): ?>
                                                <span class="badge bg-success text-white">পরিশোধ</span>
                                            <?php else: ?>
                                                <span class="badge bg-info text-white">ডিস্কাউন্ট</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($payment->type === 'credit'): ?>
                                                <span class="badge bg-danger text-white">বকেয়া</span>
                                            <?php elseif($payment->type === 'debit'): ?>
                                                <span class="badge bg-success text-white">পরিশোধ</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-white">ডিস্কাউন্ট</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-1"><?php echo e($payment->amount); ?></td>
                                    <td class="py-1">
                                        <div class="btn-list flex-nowrap">
                                            <div class="dropdown">
                                                <button class="btn btn-sm dropdown-toggle align-text-top"
                                                        data-bs-toggle="dropdown">
                                                    Actions
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a class="dropdown-item"
                                                       href="<?php echo e(route('transactions.show',$payment->id)); ?>">
                                                        View
                                                    </a>
                                                    <a class="dropdown-item"
                                                       href="<?php echo e(route('transactions.edit',$payment->id)); ?>">
                                                        Edit
                                                    </a>
                                                    <form
                                                        action="<?php echo e(route('transactions.destroy',$payment->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit"
                                                                onclick="if(!confirm('Do you Want to Proceed?')){return false;}"
                                                                class="dropdown-item text-red"><i
                                                                class="fa fa-fw fa-trash"></i>
                                                            Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td>No Data Found</td>
                            <?php endif; ?>
                            </tbody>

                        </table>
                        <div class="card-footer d-flex align-items-center">
                            <?php echo $payments->links('tablar::pagination'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="module">
        $(".select2").select2({
            width: '100%',
            theme: 'bootstrap-5',
            allowClear: true,
        });
    </script>
    <script type="module">
        document.addEventListener('DOMContentLoaded', function () {
            window.flatpickr(".flatpicker", {
                altInput: true,
                allowInput: true,
                altFormat: "d-m-Y",
                dateFormat: "Y-m-d",
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tablar::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chaler_arot\resources\views/reports/payment.blade.php ENDPATH**/ ?>