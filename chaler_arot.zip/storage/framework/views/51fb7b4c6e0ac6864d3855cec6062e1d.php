
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('date')); ?></label>
    <div>
        <?php echo e(Form::text('date', $saleReturn->date, ['class' => 'form-control' .
        ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

        <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">saleReturn <b>date</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('sale_id')); ?></label>
    <div>
        <?php echo e(Form::text('sale_id', $saleReturn->sale_id, ['class' => 'form-control' .
        ($errors->has('sale_id') ? ' is-invalid' : ''), 'placeholder' => 'Sale Id'])); ?>

        <?php echo $errors->first('sale_id', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">saleReturn <b>sale_id</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('customer_id')); ?></label>
    <div>
        <?php echo e(Form::text('customer_id', $saleReturn->customer_id, ['class' => 'form-control' .
        ($errors->has('customer_id') ? ' is-invalid' : ''), 'placeholder' => 'Customer Id'])); ?>

        <?php echo $errors->first('customer_id', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">saleReturn <b>customer_id</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('user_id')); ?></label>
    <div>
        <?php echo e(Form::text('user_id', $saleReturn->user_id, ['class' => 'form-control' .
        ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id'])); ?>

        <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">saleReturn <b>user_id</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('total')); ?></label>
    <div>
        <?php echo e(Form::text('total', $saleReturn->total, ['class' => 'form-control' .
        ($errors->has('total') ? ' is-invalid' : ''), 'placeholder' => 'Total'])); ?>

        <?php echo $errors->first('total', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">saleReturn <b>total</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('note')); ?></label>
    <div>
        <?php echo e(Form::text('note', $saleReturn->note, ['class' => 'form-control' .
        ($errors->has('note') ? ' is-invalid' : ''), 'placeholder' => 'Note'])); ?>

        <?php echo $errors->first('note', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">saleReturn <b>note</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('attachment')); ?></label>
    <div>
        <?php echo e(Form::text('attachment', $saleReturn->attachment, ['class' => 'form-control' .
        ($errors->has('attachment') ? ' is-invalid' : ''), 'placeholder' => 'Attachment'])); ?>

        <?php echo $errors->first('attachment', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">saleReturn <b>attachment</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/sale-return/form.blade.php ENDPATH**/ ?>