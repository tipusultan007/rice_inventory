<div class="row">

    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('name','নাম')); ?></label>
        <div>
            <?php echo e(Form::text('name', $user->name, ['class' => 'form-control' .
            ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>


        </div>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('email','ইমেইল')); ?></label>
        <div>
            <?php echo e(Form::text('email', $user->email, ['class' => 'form-control' .
            ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>


        </div>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('phone','মোবাইল নং')); ?></label>
        <div>
            <?php echo e(Form::text('phone', $user->phone, ['class' => 'form-control' .
            ($errors->has('phone') ? ' is-invalid' : ''), 'placeholder' => 'Phone'])); ?>

            <?php echo $errors->first('phone', '<div class="invalid-feedback">:message</div>'); ?>


        </div>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <label for="password">পাসওয়ার্ড</label></label>
        <div>
            <input class="form-control" placeholder="********" name="password" type="password" id="password">
        </div>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('address','ঠিকানা')); ?></label>
        <div>
            <?php echo e(Form::text('address', $user->address, ['class' => 'form-control' .
            ($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address'])); ?>

            <?php echo $errors->first('address', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('join_date','নিয়োগ তারিখ')); ?></label>
        <?php if (isset($component)) { $__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9 = $attributes; } ?>
<?php $component = Takielias\TablarKit\Components\Forms\Inputs\FlatPicker::resolve(['name' => 'termination_date','value' => ''.e($user->join_date).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flat-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Takielias\TablarKit\Components\Forms\Inputs\FlatPicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9)): ?>
<?php $attributes = $__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9; ?>
<?php unset($__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9)): ?>
<?php $component = $__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9; ?>
<?php unset($__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9); ?>
<?php endif; ?>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('termination_date','চাকুরিচ্যুতির তারিখ')); ?></label>
        <?php if (isset($component)) { $__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9 = $attributes; } ?>
<?php $component = Takielias\TablarKit\Components\Forms\Inputs\FlatPicker::resolve(['name' => 'termination_date','value' => ''.e($user->termination_date).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flat-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Takielias\TablarKit\Components\Forms\Inputs\FlatPicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9)): ?>
<?php $attributes = $__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9; ?>
<?php unset($__attributesOriginal3b46e4a990a47b3185b9b3a5f719fcc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9)): ?>
<?php $component = $__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9; ?>
<?php unset($__componentOriginal3b46e4a990a47b3185b9b3a5f719fcc9); ?>
<?php endif; ?>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('salary','বেতন')); ?></label>
        <div>
            <?php echo e(Form::number('salary', $user->salary, ['class' => 'form-control' .
            ($errors->has('salary') ? ' is-invalid' : ''), 'placeholder' => 'Salary'])); ?>

            <?php echo $errors->first('salary', '<div class="invalid-feedback">:message</div>'); ?>


        </div>
    </div>
    <div class="form-group col-md-4 mb-3">
        <label class="form-label">   <?php echo e(Form::label('image','ছবি')); ?></label>
        <div>
            <input type="file" name="image" class="form-control" id="image">
        </div>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">সাবমিট</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/user/form.blade.php ENDPATH**/ ?>