
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('name')); ?></label>
    <div>
        <?php echo e(Form::text('name', $user->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">user <b>name</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('email')); ?></label>
    <div>
        <?php echo e(Form::text('email', $user->email, ['class' => 'form-control' .
        ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

        <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">user <b>email</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('phone')); ?></label>
    <div>
        <?php echo e(Form::text('phone', $user->phone, ['class' => 'form-control' .
        ($errors->has('phone') ? ' is-invalid' : ''), 'placeholder' => 'Phone'])); ?>

        <?php echo $errors->first('phone', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">user <b>phone</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <label for="password">Password</label></label>
    <div>
        <input class="form-control" placeholder="********" name="password" type="password" id="password">
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('address')); ?></label>
    <div>
        <?php echo e(Form::text('address', $user->address, ['class' => 'form-control' .
        ($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address'])); ?>

        <?php echo $errors->first('address', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">user <b>address</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('join_date')); ?></label>
    <div>
        <?php echo e(Form::date('join_date', $user->join_date, ['class' => 'form-control' .
        ($errors->has('join_date') ? ' is-invalid' : ''), 'placeholder' => 'Join Date'])); ?>

        <?php echo $errors->first('join_date', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">user <b>join_date</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('termination_date')); ?></label>
    <div>
        <?php echo e(Form::date('termination_date', $user->termination_date, ['class' => 'form-control' .
        ($errors->has('termination_date') ? ' is-invalid' : ''), 'placeholder' => 'Termination Date'])); ?>

        <?php echo $errors->first('termination_date', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">user <b>termination_date</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('salary')); ?></label>
    <div>
        <?php echo e(Form::number('salary', $user->salary, ['class' => 'form-control' .
        ($errors->has('salary') ? ' is-invalid' : ''), 'placeholder' => 'Salary'])); ?>

        <?php echo $errors->first('salary', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">user <b>salary</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/user/form.blade.php ENDPATH**/ ?>