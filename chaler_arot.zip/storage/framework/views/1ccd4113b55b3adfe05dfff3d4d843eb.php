<input
    name="<?php echo e($name); ?>"
    type="text"
    id="<?php echo e($id); ?>"
    placeholder="<?php echo e($placeholder); ?>"
    <?php if($value): ?> value="<?php echo e($value); ?>" <?php endif; ?>
    <?php echo e($attributes->merge(['class' => config('tablar-kit.default-class'). ' flatpickr'])); ?>

/>

<?php if (! $__env->hasRenderedOnce('79548419-19a7-4835-ad46-b84ae0048d97')): $__env->markAsRenderedOnce('79548419-19a7-4835-ad46-b84ae0048d97'); ?>
    <?php $__env->startPush('js'); ?>
        <script type="module">
            document.addEventListener('DOMContentLoaded', function () {
                window.flatpickr(".flatpickr");
            });
        </script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('css'); ?>
        <style>

        </style>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\chaler_arot\vendor\takielias\tablar-kit\src/../resources/views/components/forms/inputs/flat-picker.blade.php ENDPATH**/ ?>