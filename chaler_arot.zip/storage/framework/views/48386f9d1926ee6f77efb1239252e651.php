<select name="<?php echo e($name); ?>"
        <?php echo e($attributes->merge(['class' => 'form-select'])); ?>

        id="<?php echo e($id); ?>">
    <?php if($placeholder): ?>
        <option value="" disabled selected><?php echo e($placeholder); ?></option>
    <?php endif; ?>
    <?php $__currentLoopData = $options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>" <?php if($value == $key): echo 'selected'; endif; ?> ><?php echo e($option); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php /**PATH C:\wamp64\www\chaler_arot\vendor\takielias\tablar-kit\src/../resources/views/components/forms/inputs/select.blade.php ENDPATH**/ ?>