
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('name')); ?></label>
    <div>
        <?php echo e(Form::text('name', $customer->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">customer <b>name</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('phone')); ?></label>
    <div>
        <?php echo e(Form::text('phone', $customer->phone, ['class' => 'form-control' .
        ($errors->has('phone') ? ' is-invalid' : ''), 'placeholder' => 'Phone'])); ?>

        <?php echo $errors->first('phone', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">customer <b>phone</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('address')); ?></label>
    <div>
        <?php echo e(Form::text('address', $customer->address, ['class' => 'form-control' .
        ($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address'])); ?>

        <?php echo $errors->first('address', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">customer <b>address</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/customer/form.blade.php ENDPATH**/ ?>