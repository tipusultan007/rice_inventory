<?php if(Session::has('message')): ?>
    <div class="alert alert-info" role="alert">
        <div class="text-muted"><?php echo e(Session('message')); ?></div>
    </div>
<?php elseif(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
        <div class="text-muted"><?php echo e(Session('success')); ?></div>
    </div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <div class="text-muted"><?php echo e(Session('error')); ?></div>
    </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/vendor/tablar/common/alert.blade.php ENDPATH**/ ?>