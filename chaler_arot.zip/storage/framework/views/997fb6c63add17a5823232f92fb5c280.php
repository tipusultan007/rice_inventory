<a href="#">
    <img src="<?php echo e(asset(config('tablar.auth_logo.img.path','assets/logo.svg'))); ?>" width="110" height="32"
         alt="<?php echo e(asset(config('tablar.title','Tablar'))); ?>"
         class="navbar-brand-image">
</a>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/vendor/tablar/partials/common/logo.blade.php ENDPATH**/ ?>