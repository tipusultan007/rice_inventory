
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('name')); ?></label>
    <div>
        <?php echo e(Form::text('name', $account->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">account <b>name</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('details')); ?></label>
    <div>
        <?php echo e(Form::text('details', $account->details, ['class' => 'form-control' .
        ($errors->has('details') ? ' is-invalid' : ''), 'placeholder' => 'Details'])); ?>

        <?php echo $errors->first('details', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">account <b>details</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('balance')); ?></label>
    <div>
        <?php echo e(Form::text('balance', $account->balance, ['class' => 'form-control' .
        ($errors->has('balance') ? ' is-invalid' : ''), 'placeholder' => 'Balance'])); ?>

        <?php echo $errors->first('balance', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">account <b>balance</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\wamp64\www\chaler_arot\resources\views/account/form.blade.php ENDPATH**/ ?>