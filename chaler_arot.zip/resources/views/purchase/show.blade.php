@extends('tablar::page')

@section('title', 'View Purchase')

@section('content')

    <style>
        .invoice {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            background: #fff;
        }
        .invoice-header {
            text-align: left; /* Align supplier information to the left */
        }


        .invoice-body table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .invoice-body th, .invoice-body td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .invoice-footer {
            margin-top: 20px;
        }
    </style>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <div class="page-pretitle">
                        View
                    </div>
                    <h2 class="page-title">
                        {{ __('Purchase ') }}
                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <a href="{{ route('purchases.index') }}" class="btn btn-primary d-none d-sm-inline-block">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19"/>
                                <line x1="5" y1="12" x2="19" y2="12"/>
                            </svg>
                            Purchase List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="invoice">
                        <div class="invoice-header">
                            <h1 class="text-center">ক্রয় চালান</h1>
                            <p><strong>তারিখ:</strong> {{ $purchase->created_at->format('Y-m-d H:i:s') }}</p>
                            <p><strong>সাপ্লাইয়ার:</strong> {{ $purchase->supplier->name }}</p>
                            <p><strong>মোবাইল নং:</strong> {{ $purchase->supplier->phone }}</p>
                            <p><strong>কোম্পানির:</strong> {{ $purchase->supplier->company }}</p>
                            <p><strong>ঠিকানা:</strong> {{ $purchase->supplier->address }}</p>
                        </div>

                        <div class="invoice-body">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="fw-bolder fs-5">চালের ধরণ</th>
                                    <th class="fw-bolder fs-5">দর</th>
                                    <th class="fw-bolder fs-5">পরিমাণ (বস্তা সংখ্যা)</th>
                                    <th class="fw-bolder fs-5">টাকা</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($purchase->purchaseDetails as $product)
                                    <tr>
                                        <td>{{ $product->product->name }}</td>
                                        <td>{{ $product->price_rate }}</td>
                                        <td>{{ $product->quantity }}</td>
                                        <td>{{ $product->amount }}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="invoice-footer">
                            <p><strong>সর্বমোট:</strong> {{ $purchase->total }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


