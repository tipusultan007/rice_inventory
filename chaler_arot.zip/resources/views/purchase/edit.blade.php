@extends('tablar::page')

@section('title', 'Update Purchase')

@section('content')
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <div class="page-pretitle">
                        Update
                    </div>
                    <h2 class="page-title">
                        {{ __('Purchase ') }}
                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <a href="{{ route('purchases.index') }}" class="btn btn-primary d-none d-sm-inline-block">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19"/>
                                <line x1="5" y1="12" x2="19" y2="12"/>
                            </svg>
                            Purchase List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            @if(config('tablar','display_alert'))
                @include('tablar::common.alert')
            @endif
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Purchase Details</h3>
                        </div>
                        <div class="card-body">
                            {{--<form method="POST"
                                  action="{{ route('purchases.update', $purchase->id) }}" id="ajaxForm" role="form"
                                  enctype="multipart/form-data">
                                {{ method_field('PATCH') }}
                                @csrf
                                @include('purchase.form')
                            </form>--}}
                            <form action="{{ route('purchases.update', $purchase->id) }}" method="post">
                                @csrf
                                @method('PUT')

                                <div class="mb-3">
                                    <label for="purchase_date" class="form-label">Purchase Date:</label>
                                    <input type="date" name="purchase_date" class="form-control" value="{{ old('purchase_date', $purchase->purchase_date) }}" required>
                                    @error('purchase_date')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="supplier_id" class="form-label">Supplier:</label>
                                    <select name="supplier_id" class="form-select" required>
                                        <option value="" disabled>Select Supplier</option>
                                        @foreach($suppliers as $supplier)
                                            <option value="{{ $supplier->id }}" {{ old('supplier_id', $purchase->supplier_id) == $supplier->id ? 'selected' : '' }}>
                                                {{ $supplier->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('supplier_id')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="user_id" class="form-label">User:</label>
                                    <select name="user_id" class="form-select" required>
                                        <option value="" disabled>Select User</option>
                                        @foreach($users as $user)
                                            <option value="{{ $user->id }}" {{ old('user_id', $purchase->user_id) == $user->id ? 'selected' : '' }}>
                                                {{ $user->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('user_id')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>



                                <div class="mb-3">
                                    <label for="additional_field" class="form-label">Additional Field:</label>
                                    <input type="text" name="additional_field" class="form-control" value="{{ old('additional_field', $purchase->additional_field) }}">
                                    @error('additional_field')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Products:</label>
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Price Rate</th>
                                            <th>Amount</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="products-container">
                                        @foreach($purchase->purchaseDetails as $index => $detail)
                                            <tr class="product-entry">
                                                <td>
                                                    <select name="products[{{ $index }}][product_id]" class="form-select product-select" required>
                                                        <option value="" disabled>Select Product</option>
                                                        @foreach($products as $product)
                                                            <option value="{{ $product->id }}" {{ old("products.$index.product_id", $detail->product_id) == $product->id ? 'selected' : '' }}>
                                                                {{ $product->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="number" name="products[{{ $index }}][quantity]" class="form-control quantity" value="{{ old("products.$index.quantity", $detail->quantity) }}" required>
                                                </td>
                                                <td>
                                                    <input type="number" name="products[{{ $index }}][price_rate]" class="form-control price_rate" step="0.01" value="{{ old("products.$index.price_rate", $detail->price_rate) }}" required>
                                                </td>
                                                <td>
                                                    <input type="number" name="products[{{ $index }}][amount]" class="form-control amount" step="0.01" value="{{ old("products.$index.amount", $detail->amount) }}" required>
                                                </td>
                                                <td>
                                                    @if($index != 0)
                                                        <button type="button" class="btn btn-danger" onclick="removeProductEntry(this)">Delete</button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>

                                <div class="mb-3">
                                    <label for="total" class="form-label">Total:</label>
                                    <input type="number" name="total" class="form-control total" step="0.01" value="{{ old('total', $purchase->total) }}" required>
                                    @error('total')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <button type="button" class="btn btn-primary" onclick="addProductEntry()">Add Product</button>

                                <button type="submit" class="btn btn-success">Update Purchase</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>

        function updateAmountAndTotal() {
            // Loop through each product entry row
            $('.product-entry').each(function(index) {
                var quantity = parseFloat($(this).find('input[name^="products[' + index + '][quantity]"]').val()) || 0;
                var priceRate = parseFloat($(this).find('input[name^="products[' + index + '][price_rate]"]').val()) || 0;
                var amount = quantity * priceRate;

                // Update the amount for the current row
                $(this).find('input[name^="products[' + index + '][amount]"]').val(amount.toFixed(2));

                // Update the total based on all amounts
                updateTotal();
            });
        }

        // Function to update the total based on all amounts
        function updateTotal() {
            var total = 0;

            // Loop through each product entry row and sum the amounts
            $('.product-entry').each(function(index) {
                var amount = parseFloat($(this).find('input[name^="products[' + index + '][amount]"]').val()) || 0;
                total += amount;
            });

            // Update the total input field
            $('input[name="total"]').val(total.toFixed(2));
        }

        function initializeEventListeners() {
            // Update amounts and total when quantity or price rate changes
            $('.product-entry input[name^="products["]').on('input', function() {
                updateAmountAndTotal();
            });

            // Remove row when the delete button is clicked
            $('.product-entry .delete-row').on('click', function() {
                var row = $(this).closest('.product-entry');
                removeProductEntry(row);
            });
        }

        initializeEventListeners();
        function addProductEntry() {
            const productsContainer = $('.product-entry:first').clone();

            // Clear input values in the new entry
            productsContainer.find('input, select').val('');

            // Increment the index for input names
            const newIndex = $('.product-entry').length;
            productsContainer.find('select').attr('name', `products[${newIndex}][product_id]`);
            productsContainer.find('input[name^="products[0]"]').each(function () {
                const currentName = $(this).attr('name');
                $(this).attr('name', currentName.replace(/\[0\]/, `[${newIndex}]`));
            });


            // Add delete button only for rows beyond the initial one
            if (newIndex > 0) {
                productsContainer.find('td:last').html('<button type="button" class="btn btn-danger" onclick="removeProductEntry(this)">Delete</button>');
            } else {
                productsContainer.find('td:last').empty(); // Remove any existing delete button in the first row
            }

            $('.table tbody').append(productsContainer);
            initializeEventListeners();
        }

        function removeProductEntry(button) {
            $(button).closest('tr').remove();

            updateAmountAndTotal();
        }
    </script>
@endsection


