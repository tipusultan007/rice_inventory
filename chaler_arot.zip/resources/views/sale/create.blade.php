@extends('tablar::page')

@section('title', 'Create Sale')

@section('content')
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <div class="page-pretitle">
                        Create
                    </div>
                    <h2 class="page-title">
                        {{ __('Sale ') }}
                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <a href="{{ route('sales.index') }}" class="btn btn-primary d-none d-sm-inline-block">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19"/>
                                <line x1="5" y1="12" x2="19" y2="12"/>
                            </svg>
                            Sale List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            @if(config('tablar','display_alert'))
                @include('tablar::common.alert')
            @endif
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Sale Details</h3>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('sales.store') }}" method="post">
                                @csrf

                                <div class="mb-3">
                                    <label for="sale_date" class="form-label">Sale Date:</label>
                                    <input type="date" name="sale_date" class="form-control" value="{{ old('sale_date') }}" required>
                                    @error('sale_date')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="customer_id" class="form-label">Customer:</label>
                                    <select name="customer_id" class="form-select" required>
                                        <option value="" disabled>Select Customer</option>
                                        @foreach($customers as $customer)
                                            <option value="{{ $customer->id }}" {{ old('customer_id') == $customer->id ? 'selected' : '' }}>
                                                {{ $customer->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('customer_id')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="user_id" class="form-label">User:</label>
                                    <select name="user_id" class="form-select" required>
                                        <option value="" disabled>Select User</option>
                                        @foreach($users as $user)
                                            <option value="{{ $user->id }}" {{ old('user_id', auth()->id()) == $user->id ? 'selected' : '' }}>
                                                {{ $user->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('user_id')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Products:</label>
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Product Name</th>
                                            <th>Price Rate</th>
                                            <th>Quantity</th>
                                            <th>Amount</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr class="product-entry">
                                            <td>
                                                <select name="products[0][product_id]" class="form-select" required>
                                                    <option value="" disabled>Select Product</option>
                                                    @foreach($products as $product)
                                                        <option value="{{ $product->id }}" {{ old("products.0.product_id") == $product->id ? 'selected' : '' }}>
                                                            {{ $product->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td><input type="number" name="products[0][price_rate]" class="form-control" value="{{ old("products.0.price_rate") }}" required></td>
                                            <td><input type="number" name="products[0][quantity]" class="form-control" value="{{ old("products.0.quantity") }}" required></td>
                                            <td><input type="number" name="products[0][amount]" class="form-control" value="{{ old("products.0.amount") }}" required></td>
                                            <td></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="mb-3">
                                    <label for="total" class="form-label">Total:</label>
                                    <input type="number" name="total" class="form-control" value="{{ old('total') }}" required>
                                    @error('total')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <button type="button" class="btn btn-primary" onclick="addProductEntry()">Add Product</button>

                                <button type="submit" class="btn btn-success">Create Sale</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function updateAmountAndTotal() {
            $('.product-entry').each(function(index) {
                var quantity = parseFloat($(this).find('input[name^="products[' + index + '][quantity]"]').val()) || 0;
                var priceRate = parseFloat($(this).find('input[name^="products[' + index + '][price_rate]"]').val()) || 0;
                var amount = quantity * priceRate;

                $(this).find('input[name^="products[' + index + '][amount]"]').val(amount.toFixed(2));

                updateTotal();
            });
        }

        function updateTotal() {
            var total = 0;
            $('.product-entry').each(function(index) {
                var amount = parseFloat($(this).find('input[name^="products[' + index + '][amount]"]').val()) || 0;
                total += amount;
            });

            $('input[name="total"]').val(total.toFixed(2));
        }

        function initializeEventListeners() {
            $('.product-entry input[name^="products["]').on('input', function() {
                updateAmountAndTotal();
            });
        }

        initializeEventListeners();

        function addProductEntry() {
            const productsContainer = $('.product-entry:first').clone();

            productsContainer.find('input, select').val('');

            const newIndex = $('.product-entry').length;
            productsContainer.find('select').attr('name', `products[${newIndex}][product_id]`);
            productsContainer.find('input[name^="products[0]"]').each(function () {
                const currentName = $(this).attr('name');
                $(this).attr('name', currentName.replace(/\[0\]/, `[${newIndex}]`));
            });

            if (newIndex > 0) {
                productsContainer.find('td:last').html('<button type="button" class="btn btn-danger" onclick="removeProductEntry(this)">Delete</button>');
            } else {
                productsContainer.find('td:last').empty();
            }

            $('.table tbody').append(productsContainer);

            initializeEventListeners();
        }

        function removeProductEntry(button) {
            $(button).closest('tr').remove();
            updateAmountAndTotal();
        }
    </script>
@endsection
