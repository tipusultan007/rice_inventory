<?php

namespace App\Http\Controllers;

use App\Models\BalanceAddition;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Class BalanceAdditionController
 * @package App\Http\Controllers
 */
class BalanceAdditionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $balanceAdditions = BalanceAddition::with('account')->orderBy('id','desc')->paginate(20);

        return view('balance-addition.index', compact('balanceAdditions'))
            ->with('i', (request()->input('page', 1) - 1) * $balanceAdditions->perPage());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $balanceAddition = new BalanceAddition();
        return view('balance-addition.create', compact('balanceAddition'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate the request
        $request->validate([
            'account_id' => 'required|exists:accounts,id',
            'amount' => 'required|numeric|min:0',
            'date' => 'required',
            'note' => 'nullable|string',
        ]);

        // Begin a database transaction
        DB::beginTransaction();

        try {
            // Create a balance addition
            $balanceAddition = BalanceAddition::create([
                'account_id' => $request->input('account_id'),
                'amount' => $request->input('amount'),
                'note' => $request->input('note'),
                'date' => $request->input('date'),
            ]);

            // Create a transaction for the balance addition
            Transaction::create([
                'account_id' => $request->input('account_id'),
                'amount' => $request->input('amount'),
                'type' => 'credit',
                'reference_id' => $balanceAddition->id,
                'date' => $balanceAddition->date,
                'transaction_type' => 'balance_addition',
            ]);

            // Commit the transaction
            DB::commit();

            return redirect()->route('balance_additions.index')
                ->with('success', 'Balance addition created successfully');
        } catch (\Exception $e) {
            // An error occurred, rollback the transaction
            DB::rollback();

            return redirect()->route('balance_additions.index')
                ->with('error', 'Balance addition creation failed.');

        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $balanceAddition = BalanceAddition::find($id);

        return view('balance-addition.show', compact('balanceAddition'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $balanceAddition = BalanceAddition::find($id);

        return view('balance-addition.edit', compact('balanceAddition'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  BalanceAddition $balanceAddition
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BalanceAddition $balanceAddition)
    {
        // Validate the request
        $request->validate([
            'amount' => 'required|numeric|min:0',
            'date' => 'required',
            'note' => 'nullable|string',
        ]);

        // Begin a database transaction
        DB::beginTransaction();

        try {
            // Update the balance addition
            $balanceAddition->update([
                'account_id' => $request->input('account_id'),
                'amount' => $request->input('amount'),
                'note' => $request->input('note'),
                'date' => $request->input('date'),
            ]);

            // Update the transaction for the balance addition
            $creditTransaction = Transaction::where('reference_id', $balanceAddition->id)
                ->where('transaction_type', 'balance_addition')
                ->where('type', 'credit')
                ->first();

            if ($creditTransaction) {
                $creditTransaction->update([
                    'account_id' => $request->input('account_id'),
                    'amount' => $request->input('amount'),
                    'date' => $request->input('date'),
                ]);
            }

            // Commit the transaction
            DB::commit();

            return redirect()->route('balance_additions.index')
                ->with('success', 'Balance addition updated successfully');
        } catch (\Exception $e) {
            // An error occurred, rollback the transaction
            DB::rollback();

            // Log the error or handle it in a way that fits your application
            // You might want to log the error, display a user-friendly message, or redirect to an error page
            throw ValidationException::withMessages(['error' => 'Balance addition update failed.']);
        }
    }
    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy(BalanceAddition $balanceAddition)
    {
        // Begin a database transaction
        DB::beginTransaction();

        try {
            // Retrieve related transaction
            $creditTransaction = Transaction::where('reference_id', $balanceAddition->id)
                ->where('transaction_type', 'balance_addition')
                ->where('type', 'credit')
                ->first();


            // Delete the related transaction
            if ($creditTransaction) {
                $creditTransaction->delete();
            }

            // Delete the balance addition
            $balanceAddition->delete();

            // Commit the transaction
            DB::commit();

            return redirect()->route('balance_additions.index')
                ->with('success', 'Balance addition deleted successfully');
        } catch (\Exception $e) {
            // An error occurred, rollback the transaction
            DB::rollback();

            return redirect()->route('balance_additions.index')
                ->with('error', 'Balance addition deletion failed.');
        }
    }
}
