<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Due
 *
 * @property $id
 * @property $customer_id
 * @property $supplier_id
 * @property $amount
 * @property $type
 * @property $invoice
 * @property $created_at
 * @property $updated_at
 *
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Due extends Model
{
    
    static $rules = [
		'amount' => 'required',
		'type' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['customer_id','supplier_id','amount','type','invoice'];



}
