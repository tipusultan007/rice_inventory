<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class BalanceAddition
 *
 * @property $id
 * @property $account_id
 * @property $amount
 * @property $created_at
 * @property $updated_at
 *
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class BalanceAddition extends Model
{

    static $rules = [
		'account_id' => 'required',
		'amount' => 'required',
		'date' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['account_id','amount','date'];

    public function account()
    {
        return $this->belongsTo(Account::class);
    }

}
