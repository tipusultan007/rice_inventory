<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Auth::routes();

Route::get('/home', [\App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::resource('customers', App\Http\Controllers\CustomerController::class);
Route::resource('suppliers', App\Http\Controllers\SupplierController::class);
Route::resource('/purchases', App\Http\Controllers\PurchaseController::class);
Route::resource('/sales', App\Http\Controllers\SaleController::class);
Route::resource('/products', App\Http\Controllers\ProductController::class);
Route::resource('/expense_categories', App\Http\Controllers\ExpenseCategoryController::class);
Route::resource('/expenses', App\Http\Controllers\ExpenseController::class);
Route::resource('/dues', App\Http\Controllers\DueController::class);
Route::resource('/users', App\Http\Controllers\UserController::class);
Route::resource('/users', App\Http\Controllers\UserController::class);
Auth::routes();

Route::get('/home', [\App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::resource('/users', App\Http\Controllers\UserController::class);
Route::resource('/dues', App\Http\Controllers\DueController::class);
Route::resource('/sale_returns', App\Http\Controllers\SaleReturnController::class);
