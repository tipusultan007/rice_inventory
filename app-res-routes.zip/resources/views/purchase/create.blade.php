@extends('tablar::page')

@section('title', 'Create Purchase')

@section('content')
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <div class="page-pretitle">
                        Create
                    </div>
                    <h2 class="page-title">
                        {{ __('Purchase ') }}
                    </h2>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <a href="{{ route('purchases.index') }}" class="btn btn-primary d-none d-sm-inline-block">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19"/>
                                <line x1="5" y1="12" x2="19" y2="12"/>
                            </svg>
                            Purchase List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            @if(config('tablar','display_alert'))
                @include('tablar::common.alert')
            @endif
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Purchase Details</h3>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('purchases.store') }}" method="post">
                                @csrf

                                <div class="mb-3">
                                    <label for="date" class="form-label">Purchase Date:</label>
                                    <input type="date" name="date" class="form-control" value="{{ old('date') }}" required>
                                    @error('date')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="supplier_id" class="form-label">Supplier:</label>
                                    <select name="supplier_id" class="form-select" required>
                                        <option value="" disabled>Select Supplier</option>
                                        @foreach($suppliers as $supplier)
                                            <option value="{{ $supplier->id }}" {{ old('supplier_id') == $supplier->id ? 'selected' : '' }}>
                                                {{ $supplier->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('supplier_id')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="truck_no" class="form-label">Truck No:</label>
                                    <input type="text" name="truck_no" class="form-control" value="{{ old('truck_no') }}">
                                    @error('truck_no')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <input type="hidden" name="user_id" value="{{ auth()->id() }}">
                                <div class="mb-3">
                                    <label class="form-label">Products:</label>
                                    <table class="table products">
                                        <thead>
                                        <tr>
                                            <th>Product Name</th>
                                            <th>Price Rate</th>
                                            <th>Quantity</th>
                                            <th>Amount</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr class="product-entry">
                                            <td>
                                                <select name="products[0][product_id]" class="form-select" required>
                                                    <option value="" disabled>Select Product</option>
                                                    @foreach($products as $product)
                                                        <option value="{{ $product->id }}" {{ old("products.0.product_id") == $product->id ? 'selected' : '' }}>
                                                            {{ $product->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td><input type="number" name="products[0][price_rate]" class="form-control" value="{{ old("products.0.price_rate") }}" required></td>
                                            <td><input type="number" name="products[0][quantity]" class="form-control" value="{{ old("products.0.quantity") }}" required></td>
                                            <td><input type="number" name="products[0][amount]" class="form-control"  value="{{ old("products.0.amount") }}" required></td>
                                            <td></td>
                                        </tr>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th colspan="3" class="text-end border-0 py-0">মোট</th>
                                            <th class="subtotal border-0 py-2">
                                                <input type="number" name="subtotal" class="form-control" readonly>
                                            </th>
                                            <th class="border-0 py-0 border-0 py-0"></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3" class="text-end border-0 py-0">গাড়ি ভাড়া</th>
                                            <th class="carrying_cost border-0 py-2">
                                                <input type="number" name="carrying_cost" class="form-control" min="0">
                                            </th>
                                            <th class="border-0 py-0"></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3" class="text-end border-0 py-0">তহরি</th>
                                            <th class="tohori border-0 py-2">
                                                <input type="number" name="tohori" class="form-control" min="0">
                                            </th>
                                            <th class="border-0 py-0"></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3" class="text-end border-0 py-0">ডিস্কাউন্ট</th>
                                            <th class="discount border-0 py-2">
                                                <input type="number" name="discount" class="form-control" min="0">
                                            </th>
                                            <th class="border-0 py-0"></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3" class="text-end border-0 py-0">সর্বমোট</th>
                                            <th class="total border-0 py-2">
                                                <input type="number" name="total" class="form-control" readonly>
                                            </th>
                                            <th class="border-0 py-0"></th>
                                        </tr>
                                        </tfoot>
                                    </table>

                                </div>
                                <div class="mb-3">
                                    <label for="note" class="form-label">নোট:</label>
                                    <input type="text" name="note" class="form-control"  value="{{ old('note') }}">
                                    @error('note')
                                    <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                                <button type="button" class="btn btn-primary" onclick="addProductEntry()">Add Product</button>

                                <button type="submit" class="btn btn-success">Create Purchase</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function addProductEntry() {
            const productsContainer = $('.product-entry:first').clone();

            // Clear input values in the new entry
            productsContainer.find('input, select').val('');

            // Increment the index for input names
            const newIndex = $('.product-entry').length;
            productsContainer.find('select').attr('name', `products[${newIndex}][product_id]`);
            productsContainer.find('input[name^="products[0]"]').each(function () {
                const currentName = $(this).attr('name');
                $(this).attr('name', currentName.replace(/\[0\]/, `[${newIndex}]`));
            });


            // Add delete button only for rows beyond the initial one
            if (newIndex > 0) {
                productsContainer.find('td:last').html('<button type="button" class="btn btn-danger" onclick="removeProductEntry(this)">Delete</button>');
            } else {
                productsContainer.find('td:last').empty(); // Remove any existing delete button in the first row
            }

            $('.table.products tbody').append(productsContainer);

            initializeEventListeners();
        }
        function updateAmountAndTotal() {
            // Loop through each product entry row
            $('.product-entry').each(function(index) {
                var quantity = parseFloat($(this).find('input[name^="products[' + index + '][quantity]"]').val()) || 0;
                var priceRate = parseFloat($(this).find('input[name^="products[' + index + '][price_rate]"]').val()) || 0;
                var amount = quantity * priceRate;

                // Update the amount for the current row
                $(this).find('input[name^="products[' + index + '][amount]"]').val(amount.toFixed(2));

                // Update the total based on all amounts
                updateTotal();
            });
        }

        // Function to update the total based on all amounts
        function updateTotal() {
            var total = 0;
            var subtotal = 0;

            // Loop through each product entry row and sum the amounts
            $('.product-entry').each(function(index) {
                var amount = parseFloat($(this).find('input[name^="products[' + index + '][amount]"]').val()) || 0;
                total += amount;
                subtotal += amount;
            });
            $('input[name="subtotal"]').val(total.toFixed(2));
            // Include carrying cost
            var carryingCost = parseFloat($('input[name="carrying_cost"]').val()) || 0;
            total += carryingCost;

            // Include discount
            var discount = parseFloat($('input[name="discount"]').val()) || 0;
            total -= discount;

            // Update the total input field
            $('input[name="total"]').val(total.toFixed(2));

        }

        function initializeEventListeners() {
            // Update amounts and total when quantity or price rate changes
            $('.product-entry input[name^="products["]').on('input', function() {
                updateAmountAndTotal();
            });

            // Update total when carrying cost or discount changes
            $('input[name="carrying_cost"], input[name="discount"]').on('input', function() {
                updateTotal();
            });
        }

        initializeEventListeners();



        function removeProductEntry(button) {
            $(button).closest('tr').remove();
            updateAmountAndTotal();
        }
    </script>
@endsection
