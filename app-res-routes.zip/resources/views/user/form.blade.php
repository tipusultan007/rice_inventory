
<div class="form-group mb-3">
    <label class="form-label">   {{ Form::label('name') }}</label>
    <div>
        {{ Form::text('name', $user->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name']) }}
        {!! $errors->first('name', '<div class="invalid-feedback">:message</div>') !!}
        <small class="form-hint">user <b>name</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   {{ Form::label('email') }}</label>
    <div>
        {{ Form::text('email', $user->email, ['class' => 'form-control' .
        ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email']) }}
        {!! $errors->first('email', '<div class="invalid-feedback">:message</div>') !!}
        <small class="form-hint">user <b>email</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   {{ Form::label('phone') }}</label>
    <div>
        {{ Form::text('phone', $user->phone, ['class' => 'form-control' .
        ($errors->has('phone') ? ' is-invalid' : ''), 'placeholder' => 'Phone']) }}
        {!! $errors->first('phone', '<div class="invalid-feedback">:message</div>') !!}
        <small class="form-hint">user <b>phone</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <label for="password">Password</label></label>
    <div>
        <input class="form-control" placeholder="********" name="password" type="password" id="password">
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   {{ Form::label('address') }}</label>
    <div>
        {{ Form::text('address', $user->address, ['class' => 'form-control' .
        ($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address']) }}
        {!! $errors->first('address', '<div class="invalid-feedback">:message</div>') !!}
        <small class="form-hint">user <b>address</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   {{ Form::label('join_date') }}</label>
    <div>
        {{ Form::date('join_date', $user->join_date, ['class' => 'form-control' .
        ($errors->has('join_date') ? ' is-invalid' : ''), 'placeholder' => 'Join Date']) }}
        {!! $errors->first('join_date', '<div class="invalid-feedback">:message</div>') !!}
        <small class="form-hint">user <b>join_date</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   {{ Form::label('termination_date') }}</label>
    <div>
        {{ Form::date('termination_date', $user->termination_date, ['class' => 'form-control' .
        ($errors->has('termination_date') ? ' is-invalid' : ''), 'placeholder' => 'Termination Date']) }}
        {!! $errors->first('termination_date', '<div class="invalid-feedback">:message</div>') !!}
        <small class="form-hint">user <b>termination_date</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   {{ Form::label('salary') }}</label>
    <div>
        {{ Form::number('salary', $user->salary, ['class' => 'form-control' .
        ($errors->has('salary') ? ' is-invalid' : ''), 'placeholder' => 'Salary']) }}
        {!! $errors->first('salary', '<div class="invalid-feedback">:message</div>') !!}
        <small class="form-hint">user <b>salary</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
